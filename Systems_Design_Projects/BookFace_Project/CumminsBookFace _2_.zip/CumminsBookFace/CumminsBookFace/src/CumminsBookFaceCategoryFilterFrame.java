import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.Font;

public class CumminsBookFaceCategoryFilterFrame extends JFrame {

	private JPanel contentPaneCategoryFilter;
	@SuppressWarnings("rawtypes")
	JList listCategories = new JList();

	/**
	 * Create the frame.
	 */
	public CumminsBookFaceCategoryFilterFrame() {

		setTitle("Cummins Book Face Category Filter ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 488, 329);
		contentPaneCategoryFilter = new JPanel();
		contentPaneCategoryFilter.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPaneCategoryFilter);
		contentPaneCategoryFilter.setLayout(null);
		
		JButton btnCategoryFilter = new JButton("Filter");
		btnCategoryFilter.setToolTipText("Click this to finalize your filtering");
		btnCategoryFilter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CategoryFilter();
			}
		});

		btnCategoryFilter.setBounds(290, 92, 140, 23);
		contentPaneCategoryFilter.add(btnCategoryFilter);
		
		JLabel lblSelectWhichCategories = new JLabel("Select which categories of books you would like to be shown");
		lblSelectWhichCategories.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblSelectWhichCategories.setBounds(24, 23, 426, 41);
		contentPaneCategoryFilter.add(lblSelectWhichCategories);
		
		JScrollPane scrollPaneListCategories = new JScrollPane();
		scrollPaneListCategories.setBounds(58, 94, 200, 129);
		contentPaneCategoryFilter.add(scrollPaneListCategories);
		listCategories.setToolTipText("<HTML>\r\nUse this window to select which categories <br>\r\nyou would like to be displayed.\r\nTo select multiple hold down alt and <br>\r\nleft click\r\n</HTML>");
		
		scrollPaneListCategories.setViewportView(listCategories);
		listCategories.setModel(new AbstractListModel() {
			String[] values = new String[] {"Autobiography", "Biography", "Humor", "Literature", "Romance", "SciFi", "Other", "YoungAdult", "Mystery", "GraphicNovel"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setToolTipText("Click this to abandon your filtering");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CancelFilter();
			}
		});
		btnCancel.setBounds(290, 200, 140, 23);
		contentPaneCategoryFilter.add(btnCancel);
	}

	private void CategoryFilter(){
		//Checks if no categories were selected and produces an error if true
		if (listCategories.getSelectedIndices().equals(null)){
			JOptionPane.showMessageDialog(this, "Please select at least one category\n" + "If you want to exit click cancel", "Error", JOptionPane.ERROR_MESSAGE);
			listCategories.grabFocus();
		}else{
			//Runs the query if at least one category was chosen
			Statement stmt = null;
			ResultSet rs = null;
			//Base query
			String theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM INVENTORY WHERE 1 = 1 AND ( 1= 2 ";
			//Arrays for getting the users selections
			int Categories[] = listCategories.getSelectedIndices();
			@SuppressWarnings("deprecation")
			Object SelectedCategories[] = listCategories.getSelectedValues();
			//Loop that adds the users selected categories to the end of the base query
			for(int i = 0, a = Categories.length; i < a; i++){
				theQuery = theQuery + " OR Category = '" + SelectedCategories[i] +"'";
				if(i == a - 1 ){
					//Ends the query when the selected categories are equal to i
					theQuery = theQuery + ");";
				}
			}
			//Outputs the query to the terminal and closes this frame
			System.out.println(theQuery);
			dispose();
			//Sets the table on the main frame to show the query data
			try{
				Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
	
				stmt = conn.createStatement();
				
				rs = stmt.executeQuery(theQuery);
				while(CumminsBookFaceFrame.tableOutput.getRowCount() > 0) 
					((DefaultTableModel) CumminsBookFaceFrame.tableOutput.getModel()).removeRow(0);
					int numColumns = rs.getMetaData().getColumnCount();
					while(rs.next()) {
						//create an object to hold a record
						Object[] row = new Object[numColumns];
						//grab the fields from the record and put them into the row
						for (int i = 0; i < numColumns; i++) {
							row[i] = rs.getObject(i+1);
						}
						//insert row into JTable
						((DefaultTableModel) CumminsBookFaceFrame.tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
					}
				//Clean up
				rs.close();
				conn.close();
			
			
			}catch(SQLException ex){
				System.out.println("SQL Exception: " + ex.getMessage());
				System.out.println("SQL State: "     + ex.getSQLState());
				System.out.println("Vendor Error: "  + ex.getErrorCode());
				ex.printStackTrace();
			} //catch	
		}
	}
	private void CancelFilter(){
		this.dispose();
	}
}
