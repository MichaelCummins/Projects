import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;

public class CumminsBookFacePriceFilterFrame extends JFrame {
	NumberFormat numFormat = NumberFormat.getNumberInstance();
	private JPanel contentPanePriceFilter;
	
	public JComboBox cbDeciders = new JComboBox();
	public JFormattedTextField ftfValueOne = new JFormattedTextField(numFormat);
	public JFormattedTextField ftfValueTwo = new JFormattedTextField(numFormat);
	public JFormattedTextField ftfValueThree = new JFormattedTextField(numFormat);
	public JFormattedTextField ftfValueFour = new JFormattedTextField(numFormat);
	private final JLabel lblLessThan = new JLabel("Less than:");
	private final JLabel lblBetween = new JLabel("Between:");
	private final JLabel lblGreaterThan = new JLabel("Greater Than:");
	private final JButton btnCancel = new JButton("Cancel");
	/**
	 * Create the frame.
	 */
	public CumminsBookFacePriceFilterFrame() {
		setTitle("Cummins Price Filter");
		setDefaultCloseOperation(0);
		setBounds(100, 100, 441, 368);
		contentPanePriceFilter = new JPanel();
		contentPanePriceFilter.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPanePriceFilter);
		contentPanePriceFilter.setLayout(null);
		ftfValueTwo.setToolTipText("Enter a number greater than your first number here");
		

		ftfValueTwo.setBounds(194, 181, 86, 17);
		contentPanePriceFilter.add(ftfValueTwo);
		ftfValueOne.setToolTipText("Enter a number greater than 0 here");
		
		ftfValueOne.setBounds(194, 126, 86, 17);
		contentPanePriceFilter.add(ftfValueOne);
		cbDeciders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SetEnabledAndNotEnabled();
			}
		});
		
		cbDeciders.setModel(new DefaultComboBoxModel(new String[] {"Filter", "<", "Between", ">"}));
		cbDeciders.setBounds(-2, 147, 86, 17);
		contentPanePriceFilter.add(cbDeciders);
		
		JButton btnFilterPrice = new JButton("Filter Price");
		btnFilterPrice.setToolTipText("Click this to filter by books retail price");
		btnFilterPrice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FilterPrice();
			}
		});
		btnFilterPrice.setBounds(311, 144, 104, 23);
		contentPanePriceFilter.add(btnFilterPrice);
		ftfValueFour.setToolTipText("Enter a number greater than 0 here");
		
		ftfValueFour.setBounds(194, 255, 86, 17);
		contentPanePriceFilter.add(ftfValueFour);
		ftfValueThree.setToolTipText("Enter a number greater than 0 here");
		

		ftfValueThree.setBounds(194, 63, 86, 17);
		contentPanePriceFilter.add(ftfValueThree);
		
		JSeparator sepLeft = new JSeparator();
		sepLeft.setOrientation(SwingConstants.VERTICAL);
		sepLeft.setBounds(94, 0, 2, 329);
		contentPanePriceFilter.add(sepLeft);
		
		JSeparator sepRight = new JSeparator();
		sepRight.setOrientation(SwingConstants.VERTICAL);
		sepRight.setBounds(290, 0, 11, 329);
		contentPanePriceFilter.add(sepRight);
		ftfValueOne.setEnabled(false);
		ftfValueTwo.setEnabled(false);
		ftfValueFour.setEnabled(false);
		ftfValueThree.setEnabled(false);
		lblLessThan.setBounds(103, 65, 85, 14);
		
		contentPanePriceFilter.add(lblLessThan);
		lblBetween.setBounds(103, 147, 85, 17);
		
		contentPanePriceFilter.add(lblBetween);
		lblGreaterThan.setBounds(106, 257, 90, 14);
		
		contentPanePriceFilter.add(lblGreaterThan);
		
		JLabel lblAnd = new JLabel("and");
		lblAnd.setBounds(227, 156, 46, 14);
		contentPanePriceFilter.add(lblAnd);
		btnCancel.setToolTipText("Click this to cancel your filter");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CancelFilter();
			}
		});
		btnCancel.setBounds(311, 237, 104, 23);
		
		contentPanePriceFilter.add(btnCancel);
		contentPanePriceFilter.setFocusCycleRoot(true);
		contentPanePriceFilter.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{cbDeciders, ftfValueThree, ftfValueOne, ftfValueTwo, ftfValueFour}));
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected void SetEnabledAndNotEnabled(){
		if(cbDeciders.getSelectedItem() == "<"){
			ftfValueOne.setEnabled(false);
			ftfValueTwo.setEnabled(false);
			ftfValueFour.setEnabled(false);
			ftfValueThree.setEnabled(true);
		}else if(cbDeciders.getSelectedItem() == ">"){
			ftfValueOne.setEnabled(false);
			ftfValueTwo.setEnabled(false);
			ftfValueThree.setEnabled(false);
			ftfValueFour.setEnabled(true);
		}else if(cbDeciders.getSelectedItem() =="Between"){
			ftfValueOne.setEnabled(true);
			ftfValueTwo.setEnabled(true);
			ftfValueThree.setEnabled(false);
			ftfValueFour.setEnabled(false);
		}
	}
	protected void FilterPrice(){
		//Checks if the user has not selected a filtering option and is trying to filter
		if (cbDeciders.getSelectedIndex() == 0) {
			JOptionPane.showMessageDialog(this, "Choose a filtering option", "Error", JOptionPane.ERROR_MESSAGE);
			cbDeciders.grabFocus();
		}
		//SQL command for when the user wants to filter by something between 0 and a number
		if (cbDeciders.getSelectedIndex() == 1) {
			if (ftfValueThree.getText().isEmpty()) {
				JOptionPane.showMessageDialog(this, "Enter a value", "Error", JOptionPane.ERROR_MESSAGE);
				ftfValueThree.grabFocus();
			}else {
				try {
					double less = Double.parseDouble(ftfValueThree.getText().replaceAll(",", ""));
					//Checks if the users number is negative and produces an error if it is
					if (less < 0) {
						JOptionPane.showMessageDialog(this, "Enter a value greater than 0", "Error", JOptionPane.ERROR_MESSAGE);
						ftfValueThree.grabFocus();
					}else {
						// If the user has put in a correct value the query will run
						ftfValueThree.setText(Double.toString(less));
						Statement stmt = null;
						ResultSet rs = null;
						String theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant "
										+ "FROM Inventory WHERE 1 = 1 AND RetailPrice < " + less + ";";
						//Outputs the query to the terminal and disposes of this frame
						System.out.println(theQuery);
						dispose();
						try {
							Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
							stmt = conn.createStatement();
							rs = stmt.executeQuery(theQuery);
							//remove previous added rows from the JTable
							while(CumminsBookFaceFrame.tableOutput.getRowCount() > 0) 
								((DefaultTableModel) CumminsBookFaceFrame.tableOutput.getModel()).removeRow(0);
								int numColumns = rs.getMetaData().getColumnCount();
								while(rs.next()) {
									//create an object to hold a record
									Object[] row = new Object[numColumns];
									//grab the fields from the record and put them into the row
									for (int i = 0; i < numColumns; i++) {
										row[i] = rs.getObject(i+1);
									}
									//insert row into JTable
									((DefaultTableModel) CumminsBookFaceFrame.tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
								}
							rs.close();
							conn.close();
						} 
						catch (SQLException ex){
							System.out.println("SQL Exception: " + ex.getMessage());
							System.out.println("SQL State: " + ex.getSQLState());
							System.out.println("Vendor Error: " + ex.getErrorCode());
							ex.printStackTrace();
						} //catch
					}
				}catch (Exception x) {
					JOptionPane.showMessageDialog(this, "Enter a correct value", "Error", JOptionPane.ERROR_MESSAGE);
					ftfValueThree.grabFocus();
				}
			}
		}
		//For when user wants to filter by price higher than a specified price
		if (cbDeciders.getSelectedIndex() == 3) {
			if (ftfValueFour.getText().isEmpty()) {
				JOptionPane.showMessageDialog(this, "Enter a value", "Error", JOptionPane.ERROR_MESSAGE);
				ftfValueFour.grabFocus();
			}else {
				try {
					double greater = Double.parseDouble(ftfValueFour.getText().replaceAll(",", ""));
					//Checks if the variable is greater than 0, if not displays an error
					if (greater < 0) {
						JOptionPane.showMessageDialog(this, "Enter a value greater than 0", "Error", JOptionPane.ERROR_MESSAGE);
						ftfValueFour.grabFocus();
					}else {
						ftfValueFour.setText(Double.toString(greater));
						Statement stmt = null;
						ResultSet rs = null;
						String theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM Inventory WHERE 1 = 1 AND RetailPrice > " + greater + ";";
						//Print query and dispose of the frame
						System.out.println(theQuery);
						dispose();
						//Pass info to mainframe						
						try {
							Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
							stmt = conn.createStatement();
							rs = stmt.executeQuery(theQuery);
							//remove previous added rows from the JTable
							while(CumminsBookFaceFrame.tableOutput.getRowCount() > 0) 
								((DefaultTableModel) CumminsBookFaceFrame.tableOutput.getModel()).removeRow(0);
								int numColumns = rs.getMetaData().getColumnCount();
								while(rs.next()) {
									//create an object to hold a record
									Object[] row = new Object[numColumns];
									//grab the fields from the record and put them into the row
									for (int i = 0; i < numColumns; i++) {
										row[i] = rs.getObject(i+1);
									}
									//insert row into JTable
									((DefaultTableModel) CumminsBookFaceFrame.tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
								}
							rs.close();
							conn.close();
						}catch (SQLException ex){
							System.out.println("SQL Exception: " + ex.getMessage());
							System.out.println("SQL State: " + ex.getSQLState());
							System.out.println("Vendor Error: " + ex.getErrorCode());
							ex.printStackTrace();
						} //catch
					}
				}catch (Exception x) {
					JOptionPane.showMessageDialog(this, "Enter a correct value", "Error", JOptionPane.ERROR_MESSAGE);
					ftfValueFour.grabFocus();
				}
			}
		}
		if (cbDeciders.getSelectedIndex() == 2) {
			if (ftfValueOne.getText().isEmpty() || ftfValueTwo.getText().isEmpty()) {
				JOptionPane.showMessageDialog(this, "Enter a correct value in both text fields", "Error", JOptionPane.ERROR_MESSAGE);
				ftfValueOne.grabFocus();
			}else{
				 double numOne = Double.parseDouble(ftfValueOne.getText().replaceAll(",", ""));
				 double numTwo = Double.parseDouble(ftfValueTwo.getText().replaceAll(",", ""));
				 
				//Checks if the numbers were entered in the correct order 
				try {
					if (numOne < 0 || numTwo < 0) {
						JOptionPane.showMessageDialog(this, "Enter a value greater than 0", "Error", JOptionPane.ERROR_MESSAGE);
						ftfValueOne.grabFocus();
					}else if (numTwo < numOne) {
						JOptionPane.showMessageDialog(this, "Enter values where the first text field is less than the second text field", "Error", JOptionPane.ERROR_MESSAGE);
						ftfValueTwo.grabFocus();
					}else {
						//Will process sql if numbers were entered correctly
						ftfValueOne.setText(Double.toString(numOne));
						ftfValueTwo.setText(Double.toString(numTwo));
						Statement stmt = null;
						ResultSet rs = null;
						String theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM Inventory WHERE 1 = 1 AND RetailPrice > " + numOne + " AND RetailPrice < " + numTwo + ";";
						System.out.println(theQuery);
						dispose();
						
						try {
							Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
							stmt = conn.createStatement();
							rs = stmt.executeQuery(theQuery);
							//remove previous added rows from the JTable
							while(CumminsBookFaceFrame.tableOutput.getRowCount() > 0) 
								((DefaultTableModel) CumminsBookFaceFrame.tableOutput.getModel()).removeRow(0);
								int numColumns = rs.getMetaData().getColumnCount();
								while(rs.next()) {
									//create an object to hold a record
									Object[] row = new Object[numColumns];
									//grab the fields from the record and put them into the row
									for (int i = 0; i < numColumns; i++) {
										row[i] = rs.getObject(i+1);
									}
									//insert row into JTable
									((DefaultTableModel) CumminsBookFaceFrame.tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
								}
							rs.close();
							conn.close();
						}catch (SQLException ex){
							System.out.println("SQL Exception: " + ex.getMessage());
							System.out.println("SQL State: " + ex.getSQLState());
							System.out.println("Vendor Error: " + ex.getErrorCode());
							ex.printStackTrace();
						} //catch
					}
					//Displays this message if the value wasnt entered correctly
				}catch (Exception x) {
					JOptionPane.showMessageDialog(this, "Enter a correct value", "Error", JOptionPane.ERROR_MESSAGE);
					ftfValueOne.grabFocus();
				}
			}
		}
	}
	private void CancelFilter(){
		this.dispose();
	}
}
