import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.beans.PropertyChangeEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;

public class CumminsBookFaceAddBookFrame extends JFrame {
	NumberFormat numFormat = NumberFormat.getNumberInstance();
	private JPanel contentPaneAddBook;
	private JTextField tfBookName;
	private JTextField tfAuthorName;
	JComboBox cbCategory = new JComboBox();
	JFormattedTextField ftfBookID = new JFormattedTextField(numFormat);
	JFormattedTextField ftfMinQuant = new JFormattedTextField(numFormat);
	JFormattedTextField ftfQOH = new JFormattedTextField(numFormat);
	JFormattedTextField ftfRetailPrice = new JFormattedTextField(numFormat);
	JFormattedTextField ftfWholesalePrice = new JFormattedTextField(numFormat);
	JButton btnOk = new JButton("OK");
	JButton btnCancel = new JButton("Cancel");
	
	
	/**
	 * Create the frame.
	 */
	public CumminsBookFaceAddBookFrame() {

		setTitle("Cummins Add Book Frame");
		setDefaultCloseOperation(0);
		setBounds(100, 100, 633, 405);
		contentPaneAddBook = new JPanel();
		contentPaneAddBook.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPaneAddBook);
		contentPaneAddBook.setLayout(null);
		
		JLabel lblBookId = new JLabel("Book ID:");
		lblBookId.setBounds(20, 18, 70, 32);
		contentPaneAddBook.add(lblBookId);
		
		JLabel lblBookName = new JLabel("Book Name:");
		lblBookName.setBounds(20, 61, 80, 32);
		contentPaneAddBook.add(lblBookName);
		
		JLabel lblAuthorName = new JLabel("Author Name:");
		lblAuthorName.setBounds(20, 104, 80, 25);
		contentPaneAddBook.add(lblAuthorName);
		
		JLabel lblCategory = new JLabel("Category:");
		lblCategory.setBounds(20, 155, 80, 25);
		contentPaneAddBook.add(lblCategory);
		
		JLabel lblWholesalePrice = new JLabel("Wholesale Price:");
		lblWholesalePrice.setBounds(20, 200, 105, 25);
		contentPaneAddBook.add(lblWholesalePrice);
		
		JLabel lblQoh = new JLabel("QOH:");
		lblQoh.setBounds(20, 236, 95, 25);
		contentPaneAddBook.add(lblQoh);
		
		JLabel lblMinquant = new JLabel("MinQuant:");
		lblMinquant.setBounds(20, 283, 95, 25);
		contentPaneAddBook.add(lblMinquant);
		
		tfBookName = new JTextField();
		tfBookName.setToolTipText("Enter the name of the book here");
		tfBookName.setBounds(124, 64, 169, 26);
		contentPaneAddBook.add(tfBookName);
		tfBookName.setColumns(10);
		
		tfAuthorName = new JTextField();
		tfAuthorName.setToolTipText("Enter the books author here");
		tfAuthorName.setColumns(10);
		tfAuthorName.setBounds(124, 103, 169, 26);
		contentPaneAddBook.add(tfAuthorName);
		cbCategory.setToolTipText("Choose the best category of the book's genre");

		
		
		
		cbCategory.setModel(new DefaultComboBoxModel(new String[] {"--Choose Category --", "Humor", "Biography", "Autobiography", "Literature", "Mystery", "GraphicNovel", "YoungAdult", "Romance", "SciFi", "Other"}));
		cbCategory.setBounds(124, 155, 169, 25);
		contentPaneAddBook.add(cbCategory);
		ftfQOH.setToolTipText("Enter the quantity on hand here");
		
		
		ftfQOH.setBounds(124, 238, 169, 23);
		contentPaneAddBook.add(ftfQOH);
		ftfMinQuant.setToolTipText("Enter the minimun quantity that must be in supply here");
		
		
		ftfMinQuant.setBounds(125, 284, 169, 23);
		contentPaneAddBook.add(ftfMinQuant);
		ftfBookID.setToolTipText("Enter the ID number of the book here");
		
		ftfBookID.setBounds(124, 23, 169, 23);
		contentPaneAddBook.add(ftfBookID);
		btnOk.setToolTipText("Click here to finalize your book addition");
		

		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnOk_actionPerformed(arg0);
			}
		});
		btnOk.setBounds(396, 88, 89, 23);
		contentPaneAddBook.add(btnOk);
		btnCancel.setToolTipText("<HTML>\r\nClick here to abandon your book addition <br>\r\nand return to the home frame\r\n</HTML>");
		

		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DisposeWindow();
			}
		});
		btnCancel.setBounds(396, 177, 89, 23);
		contentPaneAddBook.add(btnCancel);
		
		JLabel lblRetailPrice = new JLabel("Retail Price:");
		lblRetailPrice.setBounds(20, 319, 70, 14);
		contentPaneAddBook.add(lblRetailPrice);
		ftfRetailPrice.setToolTipText("Enter the retail price of the book here");
		
		
		ftfRetailPrice.setBounds(124, 318, 169, 23);
		contentPaneAddBook.add(ftfRetailPrice);
		ftfWholesalePrice.setToolTipText("Enter the wholesale price of the book here");
		
		
		ftfWholesalePrice.setBounds(125, 201, 169, 23);
		contentPaneAddBook.add(ftfWholesalePrice);
		contentPaneAddBook.setFocusCycleRoot(true);
		contentPaneAddBook.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{ftfBookID, tfBookName, tfAuthorName, cbCategory, ftfWholesalePrice, ftfQOH, ftfMinQuant, ftfRetailPrice}));
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected void do_btnOk_actionPerformed(ActionEvent arg0){
		//Checks if Book ID is not empty, if it is displays an error
		if(ftfBookID.getText().isEmpty()){
			JOptionPane.showMessageDialog(this, "Please enter a bookID", "Error", JOptionPane.ERROR_MESSAGE);
			ftfBookID.grabFocus();
		}else{
			//If Book ID is filled out will input the info
			ResultSet rs = null;
			Statement stmt = null;
			String insQuery;
			
			String dupCheck = null;
			double bookid = Double.parseDouble(ftfBookID.getText().trim().replaceAll(",", ""));
			double saleprice = Double.parseDouble(ftfWholesalePrice.getText().trim().replaceAll(",", ""));
			double retailprice = Double.parseDouble(ftfRetailPrice.getText().replaceAll(",", ""));
			double qoh = Double.parseDouble(ftfQOH.getText().replaceAll(",", ""));
			double minquant = Double.parseDouble(ftfMinQuant.getText().replaceAll(",", ""));
			try{
				Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
				
				//Create the statement to check for duplicates, will look at authg
				stmt = conn.createStatement();
				dupCheck = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM INVENTORY WHERE BookID = "
						+ "" + bookid +";" ;
				System.out.println(dupCheck);
				
				//Execute the duplicate check
				rs = stmt.executeQuery(dupCheck);
				
				//If anything is returned, we have a problem
				
				if (rs.next()){
					System.out.println("No duplicates allowed");
				}else{
				//Create the statement
				stmt= conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				
				insQuery = "INSERT INTO INVENTORY(BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant) VALUES(";
				insQuery += bookid + ", ";
				insQuery += "'" + tfBookName.getText().trim() + "',";
				insQuery += "'" + tfAuthorName.getText().trim() + "',";
				insQuery += "'" + cbCategory.getSelectedItem() +"',";
				insQuery +=	saleprice +",";
				insQuery +=	retailprice +",";
				insQuery += qoh+",";
				insQuery += minquant+");";
				System.out.println(insQuery);
				
				//Execute
				
				if(stmt.executeUpdate(insQuery) != 0){
					System.out.println("Insert Successful");
				}else
					System.out.println("Insert Failed");
				}
				//Clean up
				rs.close();
				conn.close();
				
				
				
			}catch (SQLException ex){
				System.out.println("SQL Exception: " + ex.getMessage());
				System.out.println("SQL State: "     + ex.getSQLState());
				System.out.println("Vendor Error: "  + ex.getErrorCode());
				ex.printStackTrace();
			} //catch	
			this.dispose();
			CumminsBookFaceFrame frame = new CumminsBookFaceFrame();
			frame.setVisible(true);
		}			
	}
	public void DisposeWindow(){
		this.dispose();
		CumminsBookFaceFrame frame = new CumminsBookFaceFrame();
		frame.setVisible(true);
	}
}
