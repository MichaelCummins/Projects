import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;

public class CumminsBookFaceFrame extends JFrame {

	private JPanel contentPaneMainFrame;
	public static JTable tableOutput;
	JButton btnCancelSorting = new JButton("Cancel Sorting");
	JButton btnCancelAll = new JButton("Cancel All");
	public JLabel lblCurrentlyFilteringBy = new JLabel("You are currently filtering by: Nothing");
	JLabel lblCurrentlySortedBy = new JLabel("You are currently viewing sorted by: Book ID");
	JButton btnCancelFiltering = new JButton("Cancel Filtering");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CumminsBookFaceFrame frame = new CumminsBookFaceFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CumminsBookFaceFrame() {
		setTitle("Cummins BookFace MainFrame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 892, 673);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnFile.add(mntmExit);
		
		JMenu mnTools = new JMenu("Tools");
		menuBar.add(mnTools);
		
		JMenuItem mntmAddBook = new JMenuItem("Add Book...");
		mntmAddBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addBook();
			}
		});
		mnTools.add(mntmAddBook);
		
		JMenu mnSetSort = new JMenu("Set Sort");
		mnTools.add(mnSetSort);
		
		JMenuItem mntmByBookName = new JMenuItem("By Book Name");
		mntmByBookName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmByBookName_actionPerformed(e);
				lblCurrentlySortedBy.setText("You are currently viewing sorted by: Book Name");
				btnCancelSorting.setEnabled(true);
				btnCancelAll.setEnabled(true);
			}
		});
		mnSetSort.add(mntmByBookName);
		
		JMenuItem mntmByRetailPrice = new JMenuItem("By Retail Price");
		mntmByRetailPrice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmByRetailPrice_actionPerformed(e);
				lblCurrentlySortedBy.setText("You are currently viewing sorted by: Retail Price");
				btnCancelSorting.setEnabled(true);
				btnCancelAll.setEnabled(true);
			}
		});
		mnSetSort.add(mntmByRetailPrice);
		
		JMenuItem mntmByCategory = new JMenuItem("By Category");
		mntmByCategory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmByCategory_actionPerformed(e);
				lblCurrentlySortedBy.setText("You are currently viewing sorted by: Category");
				btnCancelSorting.setEnabled(true);
				btnCancelAll.setEnabled(true);
			}
		});
		mnSetSort.add(mntmByCategory);
		
		JMenu mnSetFilter = new JMenu("Set Filter");
		mnTools.add(mnSetFilter);
		
		JMenuItem mntmByRetailPrice_1 = new JMenuItem("By Retail Price...");
		mntmByRetailPrice_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FilterRetailPrice();
			}
		});
		mnSetFilter.add(mntmByRetailPrice_1);
		
		JMenuItem mntmByCategory_1 = new JMenuItem("By Category...");
		mntmByCategory_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SortByCategory();
			}
		});
		mnSetFilter.add(mntmByCategory_1);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem mntmDisplayHelp = new JMenuItem("Display Help");
		mntmDisplayHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,
						"This application is designed to display a database \n"
						+"in a user interface and allow for adding, sorting, \n"
						+"and filtering of specific items in the database. \n"
						+"Start by trying to add a book using the tools menu item 'add book...' \n"
						+"If you require further assistance mouseover any item you do "
						+"not understand for a helpful tooltip");
				
			}
		});
		mnHelp.add(mntmDisplayHelp);
		contentPaneMainFrame = new JPanel();
		contentPaneMainFrame.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPaneMainFrame);
		contentPaneMainFrame.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(39, 29, 827, 465);
		contentPaneMainFrame.add(scrollPane);
		
		tableOutput = new JTable();
		tableOutput.setToolTipText("This is your current database view");
		scrollPane.setViewportView(tableOutput);
		tableOutput.setFont(new Font("Courier New", Font.PLAIN, 11));
		tableOutput.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null},
			},
			new String[] {
				"BookID", "BookName", "AuthorName", "Category", "WholesalePrice", "RetailPrice", "QOH", "MinQuant"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, String.class, Double.class, Double.class, Integer.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tableOutput.getColumnModel().getColumn(0).setPreferredWidth(44);
		tableOutput.getColumnModel().getColumn(1).setPreferredWidth(126);
		tableOutput.getColumnModel().getColumn(2).setPreferredWidth(129);
		tableOutput.getColumnModel().getColumn(4).setPreferredWidth(85);
		tableOutput.getColumnModel().getColumn(5).setPreferredWidth(60);
		tableOutput.getColumnModel().getColumn(6).setPreferredWidth(56);
		tableOutput.getColumnModel().getColumn(7).setPreferredWidth(56);
		

		lblCurrentlySortedBy.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblCurrentlySortedBy.setBounds(49, 505, 371, 42);
		contentPaneMainFrame.add(lblCurrentlySortedBy);
		
		lblCurrentlyFilteringBy.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblCurrentlyFilteringBy.setBounds(49, 558, 371, 42);
		contentPaneMainFrame.add(lblCurrentlyFilteringBy);
		
		
		btnCancelFiltering.setToolTipText("Click this to cancel filtering");
		btnCancelFiltering.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCancelFiltering.setEnabled(false);
				lblCurrentlySortedBy.setText("You are currently viewing sorted by: Book ID");
				lblCurrentlyFilteringBy.setText("You are currently filtering by: Nothing");
				btnCancelAll.setEnabled(false);
				btnCancelSorting.setEnabled(false);
				btnCancelFiltering.setEnabled(false);
				try {
					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ResultSet rs = null;
				Statement stmt = null;
				String theQuery;
				
				try{
					//Establish the connection
					Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
					
					//Create the SQL statement
					stmt = conn.createStatement();
					
					theQuery = "SELECT * FROM INVENTORY";
				
					//Run the statement
					rs = stmt.executeQuery(theQuery);
					
					while(tableOutput.getRowCount() > 0)
						((DefaultTableModel) tableOutput.getModel()).removeRow(0);
						
					int numColumns = rs.getMetaData().getColumnCount();
					
					while(rs.next()){
						//Create an object to hold a record
						
						Object[] row = new Object[numColumns];
						
						//Grab the fields from the record and put them into the row
						
						for (int i=0;i<numColumns;i++){
							row[i]=rs.getObject(i+1);
						}
						
						//Insert this row into JTable
						
						((DefaultTableModel) tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
						
					}
					//Clean up
					rs.close();
					conn.close();
				}catch (SQLException ex){
					System.out.println("SQL Exception: " + ex.getMessage());
					System.out.println("SQL State: " + ex.getSQLState());
					System.out.println("Vendor Error: " + ex.getErrorCode());
					ex.printStackTrace();
				} //catch
			}
		});
		btnCancelFiltering.setEnabled(false);
		btnCancelFiltering.setBounds(452, 559, 123, 23);
		contentPaneMainFrame.add(btnCancelFiltering);
		
		JButton btnCancelAll = new JButton("Cancel All");
		btnCancelAll.setToolTipText("Click this to cancel sorting and filtering");
		btnCancelAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblCurrentlySortedBy.setText("You are currently viewing sorted by: Book ID");
				lblCurrentlyFilteringBy.setText("You are currently filtering by: Nothing");
				btnCancelAll.setEnabled(false);
				btnCancelSorting.setEnabled(false);
				btnCancelFiltering.setEnabled(false);
				try {
					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ResultSet rs = null;
				Statement stmt = null;
				String theQuery;
				
				try{
					//Establish the connection
					Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
					
					//Create the SQL statement
					stmt = conn.createStatement();
					
					theQuery = "SELECT * FROM INVENTORY";
				
					//Run the statement
					rs = stmt.executeQuery(theQuery);
					
					while(tableOutput.getRowCount() > 0)
						((DefaultTableModel) tableOutput.getModel()).removeRow(0);
						
					int numColumns = rs.getMetaData().getColumnCount();
					
					while(rs.next()){
						//Create an object to hold a record
						
						Object[] row = new Object[numColumns];
						
						//Grab the fields from the record and put them into the row
						
						for (int i=0;i<numColumns;i++){
							row[i]=rs.getObject(i+1);
						}
						
						//Insert this row into JTable
						
						((DefaultTableModel) tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
						
					}
					//Clean up
					rs.close();
					conn.close();
				}catch (SQLException ex){
					System.out.println("SQL Exception: " + ex.getMessage());
					System.out.println("SQL State: " + ex.getSQLState());
					System.out.println("Vendor Error: " + ex.getErrorCode());
					ex.printStackTrace();
				} //catch
			}
		});
		btnCancelAll.addMouseMotionListener(new MouseMotionAdapter() {
			
			//Mouseover enables cancel all button
			@Override
			public void mouseMoved(MouseEvent e) {
				if(lblCurrentlySortedBy.getText() != "You are currently viewing sorted by: Book ID" || lblCurrentlyFilteringBy.getText() != "You are currently filtering by: Nothing"  ||
					lblCurrentlyFilteringBy.getText() != "You are currently filtering by: Nothing"){
					btnCancelAll.setEnabled(true);
				}else{
					btnCancelAll.setEnabled(false);
				}
			}
		});
		btnCancelAll.setEnabled(false);


		btnCancelAll.setEnabled(false);
		btnCancelAll.setBounds(644, 540, 123, 23);
		contentPaneMainFrame.add(btnCancelAll);
		btnCancelSorting.setToolTipText("Click this to cancel sorting");
		
		
		btnCancelSorting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CancelSorting(e);
			}
		});
		btnCancelSorting.setEnabled(false);
		btnCancelSorting.setBounds(452, 518, 123, 23);
		contentPaneMainFrame.add(btnCancelSorting);
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//On boot up table will display the database
		ResultSet rs = null;
		Statement stmt = null;
		String theQuery;
		
		try{
			//Establish the connection
			Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
			
			//Create the SQL statement
			stmt = conn.createStatement();
			
			theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM INVENTORY";
		
			//Run the statement
			rs = stmt.executeQuery(theQuery);
			
			while(tableOutput.getRowCount() > 0)
				((DefaultTableModel) tableOutput.getModel()).removeRow(0);
				
			int numColumns = rs.getMetaData().getColumnCount();
			
			while(rs.next()){
				//Create an object to hold a record
				
				Object[] row = new Object[numColumns];
				
				//Grab the fields from the record and put them into the row
				
				for (int i=0;i<numColumns;i++){
					row[i]=rs.getObject(i+1);
				}
				
				//Insert this row into JTable
				
				((DefaultTableModel) tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
				
			}
			//Clean up
			rs.close();
			conn.close();
		}catch (SQLException ex){
			System.out.println("SQL Exception: " + ex.getMessage());
			System.out.println("SQL State: " + ex.getSQLState());
			System.out.println("Vendor Error: " + ex.getErrorCode());
			ex.printStackTrace();
		} //catch
	}
	protected void do_mntmByBookName_actionPerformed(ActionEvent e){
		//Sorts by Book name
		ResultSet rs = null;
		Statement stmt = null;
		String theQuery;
		
		try{
			//Establish the connection
			Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
			
			//Create the SQL statement
			stmt = conn.createStatement();
			
			theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM INVENTORY ORDER BY BookName ASC;";
		
			//Run the statement
			rs = stmt.executeQuery(theQuery);
			
			while(tableOutput.getRowCount() > 0)
				((DefaultTableModel) tableOutput.getModel()).removeRow(0);
				
			int numColumns = rs.getMetaData().getColumnCount();
			
			while(rs.next()){
				//Create an object to hold a record
				
				Object[] row = new Object[numColumns];
				
				//Grab the fields from the record and put them into the row
				
				for (int i=0;i<numColumns;i++){
					row[i]=rs.getObject(i+1);
				}
				
				//Insert this row into JTable
				
				((DefaultTableModel) tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
				
			}
			//Clean up
			rs.close();
			conn.close();
		}catch (SQLException ex){
			System.out.println("SQL Exception: " + ex.getMessage());
			System.out.println("SQL State: " + ex.getSQLState());
			System.out.println("Vendor Error: " + ex.getErrorCode());
			ex.printStackTrace();
		} //catch 
	}
	protected void do_mntmByRetailPrice_actionPerformed(ActionEvent e){
		//Sorts by retail price
		ResultSet rs = null;
		Statement stmt = null;
		String theQuery;
		
		try{
			//Establish the connection
			Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
			
			//Create the SQL statement
			stmt = conn.createStatement();
			
			theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM INVENTORY ORDER BY RetailPrice ASC;";
		
			//Run the statement
			rs = stmt.executeQuery(theQuery);
			
			while(tableOutput.getRowCount() > 0)
				((DefaultTableModel) tableOutput.getModel()).removeRow(0);
				
			int numColumns = rs.getMetaData().getColumnCount();
			
			while(rs.next()){
				//Create an object to hold a record
				
				Object[] row = new Object[numColumns];
				
				//Grab the fields from the record and put them into the row
				
				for (int i=0;i<numColumns;i++){
					row[i]=rs.getObject(i+1);
				}
				
				//Insert this row into JTable
				
				((DefaultTableModel) tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
				
			}
			//Clean up
			rs.close();
			conn.close();
		}catch (SQLException ex){
			System.out.println("SQL Exception: " + ex.getMessage());
			System.out.println("SQL State: " + ex.getSQLState());
			System.out.println("Vendor Error: " + ex.getErrorCode());
			ex.printStackTrace();
		} //catch 
	}
	protected void do_mntmByCategory_actionPerformed(ActionEvent e){
		//Sorts by category
		ResultSet rs = null;
		Statement stmt = null;
		String theQuery;
		
		try{
			//Establish the connection
			Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
			
			//Create the SQL statement
			stmt = conn.createStatement();
			
			theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM INVENTORY ORDER BY Category ASC;";
		
			//Run the statement
			rs = stmt.executeQuery(theQuery);
			
			while(tableOutput.getRowCount() > 0)
				((DefaultTableModel) tableOutput.getModel()).removeRow(0);
				
			int numColumns = rs.getMetaData().getColumnCount();
			
			while(rs.next()){
				//Create an object to hold a record
				
				Object[] row = new Object[numColumns];
				
				//Grab the fields from the record and put them into the row
				
				for (int i=0;i<numColumns;i++){
					row[i]=rs.getObject(i+1);
				}
				
				//Insert this row into JTable
				
				((DefaultTableModel) tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
				
			}
			//Clean up
			rs.close();
			conn.close();
		}catch (SQLException ex){
			System.out.println("SQL Exception: " + ex.getMessage());
			System.out.println("SQL State: " + ex.getSQLState());
			System.out.println("Vendor Error: " + ex.getErrorCode());
			ex.printStackTrace();
		} //catch 
	}
	protected void CancelSorting(ActionEvent e){
		//Cancels all sorting
		ResultSet rs = null;
		Statement stmt = null;
		String theQuery;
		
		try{
			//Establish the connection
			Connection conn = DriverManager.getConnection("jdbc:ucanaccess://C:/Users/Public/BookFace.accdb");
			
			//Create the SQL statement
			stmt = conn.createStatement();
			
			theQuery = "SELECT BookID, BookName, AuthorName, Category, WholesalePrice, RetailPrice, QOH, MinQuant FROM INVENTORY ORDER BY BookID ASC;";
		
			//Run the statement
			rs = stmt.executeQuery(theQuery);
			
			while(tableOutput.getRowCount() > 0)
				((DefaultTableModel) tableOutput.getModel()).removeRow(0);
				
			int numColumns = rs.getMetaData().getColumnCount();
			
			while(rs.next()){
				//Create an object to hold a record
				
				Object[] row = new Object[numColumns];
				
				//Grab the fields from the record and put them into the row
				
				for (int i=0;i<numColumns;i++){
					row[i]=rs.getObject(i+1);
				}
				
				//Insert this row into JTable
				
				((DefaultTableModel) tableOutput.getModel()).insertRow(rs.getRow() - 1, row);
				
			}
			//Clean up
			rs.close();
			conn.close();
		}catch (SQLException ex){
			System.out.println("SQL Exception: " + ex.getMessage());
			System.out.println("SQL State: " + ex.getSQLState());
			System.out.println("Vendor Error: " + ex.getErrorCode());
			ex.printStackTrace();
		} //catch 
		
		lblCurrentlySortedBy.setText("You are currently viewing sorted by: Book ID");
		btnCancelSorting.setEnabled(false);
	}
	protected void SortByCategory(){
		CumminsBookFaceCategoryFilterFrame frame = new CumminsBookFaceCategoryFilterFrame();
		frame.setVisible(true);
		lblCurrentlyFilteringBy.setText("You are currently filtering by: Category");
		btnCancelFiltering.setEnabled(true);
	}
	protected void DisposeWindow(){
		this.setVisible(false);
	}
	
	protected void FilterRetailPrice(){
		CumminsBookFacePriceFilterFrame frame = new CumminsBookFacePriceFilterFrame();
		frame.setVisible(true);
		lblCurrentlyFilteringBy.setText("You are currently filtering by: Retail Price");
		btnCancelFiltering.setEnabled(true);
	}
	protected void addBook(){
		CumminsBookFaceAddBookFrame frame = new CumminsBookFaceAddBookFrame();
		frame.setVisible(true);
		this.dispose();
	}
}