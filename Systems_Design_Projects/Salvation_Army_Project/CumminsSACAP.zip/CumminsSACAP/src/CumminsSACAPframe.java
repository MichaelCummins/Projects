import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import javax.swing.JRadioButton;
import java.beans.PropertyChangeListener;
import java.text.NumberFormat;
import java.beans.PropertyChangeEvent;
import javax.swing.ButtonGroup;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import java.util.Date;
import java.util.Calendar;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;

public class CumminsSACAPframe extends JFrame {

	
	NumberFormat numFormat = NumberFormat.getNumberInstance();
	private JPanel contentPane;
	private JTextField tfFirstName;
	private JTextField tfLastName;
	private JTextField tfAddress;
	private JTextField tfEmail;
	private final ButtonGroup btngrpRentMort = new ButtonGroup();
	private final ButtonGroup btngrpTransitGas = new ButtonGroup();
	private final JFormattedTextField ftfSupport = new JFormattedTextField(numFormat);
	private final JFormattedTextField ftfEmployment = new JFormattedTextField(numFormat);
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnHelp = new JMenu("Help");
	private final JMenu mnFile = new JMenu("File");
	private final JMenuItem mntmExit = new JMenuItem("Exit");
	private final JMenuItem mntmStartNewForm = new JMenuItem("Start New Form");
	private final JMenuItem mntmApplicantPanelHelp = new JMenuItem("Applicant Panel Help");
	private final JMenuItem mntmChildPanelHelp = new JMenuItem("Child Panel Help");
	private final JMenuItem mntmFinancialPanelHelp = new JMenuItem("Financial Panel Help");
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel ApplicantPanel = new JPanel();
	private final JLabel lblFirstName = new JLabel("First Name:");
	private final JLabel lblLastName = new JLabel("Last Name:");
	private final JLabel lblAddress = new JLabel("Address:");
	private final JLabel lblPostalCode = new JLabel("Postal Code:");
	private final JLabel lblPhoneNumber = new JLabel("Phone number:");
	private final JLabel lblAdults = new JLabel("Number of Adults:");
	private final JFormattedTextField ftfPostalCode = new JFormattedTextField();
	private final JFormattedTextField ftfPhone = new JFormattedTextField();
	private final JFormattedTextField ftfAdults = new JFormattedTextField();
	private final JLabel lblChildrenOver = new JLabel("Number of Children 18+:");
	private final JFormattedTextField ftfChildrenOver = new JFormattedTextField();
	private final JLabel lblChildrenUnder = new JLabel("Number of Children 0-17:");
	private final JFormattedTextField ftfChildrenUnder = new JFormattedTextField();
	private final JLabel lblEmail = new JLabel("Email:");
	private final JPanel FinancePanel = new JPanel();
	private final JPanel ChildPanel = new JPanel();
	private final JLabel lblEmploymenttotal = new JLabel("Employment (total):");
	private final JLabel lblSupport = new JLabel("Child/Spousal Support:");
	private final JLabel lblOntario = new JLabel("Ontario Works:");
	private final JFormattedTextField ftfOntario = new JFormattedTextField(numFormat);
	private final JLabel lblDisability = new JLabel("E.I or Disability:");
	private final JFormattedTextField ftfDisability = new JFormattedTextField(numFormat);
	private final JLabel lblPensionIncome = new JLabel("Pension Income:");
	private final JFormattedTextField ftfPensionIncome = new JFormattedTextField(numFormat);
	private final JLabel lblChildTaxCredits = new JLabel("Child Tax Credits:");
	private final JFormattedTextField ftfChildTaxCredits = new JFormattedTextField(numFormat);
	private final JRadioButton rdbtnRent = new JRadioButton("Rent");
	private final JRadioButton rdbtnMortgage = new JRadioButton("Mortgage");
	private final JFormattedTextField ftfRentMortgage = new JFormattedTextField(numFormat);
	private final JLabel lblGasHydro = new JLabel("Gas + Hydro:");
	private final JFormattedTextField ftfGasHydro = new JFormattedTextField(numFormat);
	private final JLabel lblPhoneTv = new JLabel("Phone + TV:");
	private final JFormattedTextField ftfPhoneTv = new JFormattedTextField(numFormat);
	private final JLabel lblChildCare = new JLabel("Child Care:");
	private final JFormattedTextField ftfChildCare = new JFormattedTextField(numFormat);
	private final JRadioButton rdbtnTransit = new JRadioButton("Transit");
	private final JRadioButton rdbtnGas = new JRadioButton("Gas");
	private final JFormattedTextField ftfTransitGas = new JFormattedTextField(numFormat);
	private final JLabel lblLoansInsurance = new JLabel("Loans + Insurance");
	private final JFormattedTextField ftfLoansInsurance = new JFormattedTextField(numFormat);
	private final JLabel lblTotalExpenses = new JLabel("Total Expenses:");
	private final JLabel lblIncome = new JLabel("Total Income:");
	private final JLabel lblNetIncome = new JLabel("Net Income:");
	private final JSeparator sepFinTopLeft = new JSeparator();
	private final JSeparator sepFinTopTopLeftHor = new JSeparator();
	private final JSeparator sepFinTopLeftMid = new JSeparator();
	private final JSeparator sepFinBotLeftMid = new JSeparator();
	private final JSeparator sepFinBotLeft = new JSeparator();
	private final JSeparator sepFinBotRightHor = new JSeparator();
	private final JSeparator sepFinBotRightMid = new JSeparator();
	private final JSeparator sepFinTopRightMid = new JSeparator();
	private final JSeparator sepFinTopRight = new JSeparator();
	private final JSeparator sepFinTopTopRightHor = new JSeparator();
	private final JSeparator sepFinMiddleVert = new JSeparator();
	private final JSeparator sepFinBotBotRight = new JSeparator();
	private final JSeparator sepFinBotRight = new JSeparator();
	JLabel lblWhatAreYour = new JLabel("What are your childs interests?");
	JLabel lblAge = new JLabel("Age:");
	JLabel lblChildFirstName = new JLabel("Child First Name:");
	JLabel lblBirthdate = new JLabel("Birthdate (mm/dd/yy):");
	JFormattedTextField ftfChild1Name = new JFormattedTextField();
	JFormattedTextField ftfChild3Name = new JFormattedTextField();
	JFormattedTextField ftfChild2Name = new JFormattedTextField();
	JLabel lblGender = new JLabel("Gender:");
	JLabel lblWhatGameSystems = new JLabel("What game system do you have?");
	JFormattedTextField ftfChild1Shoe = new JFormattedTextField(numFormat);
	JFormattedTextField ftfChild2Shoe = new JFormattedTextField(numFormat);
	JFormattedTextField ftfChild3Shoe = new JFormattedTextField(numFormat);
	JLabel lblCoatSize = new JLabel("Coat Size:");
	JLabel lblShoeSize = new JLabel("Shoe Size:");
	JLabel lblClothingSize = new JLabel("Clothing Size:");
	JFormattedTextField ftfChild1Coat = new JFormattedTextField(numFormat);
	JFormattedTextField ftfChild2Coat = new JFormattedTextField(numFormat);
	JFormattedTextField ftfChild3Coat = new JFormattedTextField(numFormat);
	JRadioButton rdbtnChild1Male = new JRadioButton("Male");
	JRadioButton rdbtnChild1Female = new JRadioButton("Female");
	JRadioButton rdbtnChild2Male = new JRadioButton("Male");
	JRadioButton rdbtnChild2Female = new JRadioButton("Female");
	JRadioButton rdbtnChild3Female = new JRadioButton("Female");
	JRadioButton rdbtnChild3Male = new JRadioButton("Male");
	JFormattedTextField ftfChild1Age = new JFormattedTextField(numFormat);
	JFormattedTextField ftfChild2Age = new JFormattedTextField(numFormat);
	JFormattedTextField ftfChild3Age = new JFormattedTextField(numFormat);
	
	MaskFormatter PhoneMask = createFormatter("(###)-###-####");
	MaskFormatter PostalCodeMask = createFormatter("#####");
	MaskFormatter AdultsMask = createFormatter("##");
	MaskFormatter ChildrenOverMask = createFormatter("##");
	MaskFormatter ChildrenUnderMask = createFormatter("##");
	MaskFormatter EmploymentMask = createFormatter("######.##");
	MaskFormatter SupportMask = createFormatter("######.##");
	MaskFormatter OntarioMask = createFormatter("######.##");
	MaskFormatter DisabilityMask = createFormatter("######.##");
	MaskFormatter PensionMask = createFormatter("######.##");
	MaskFormatter ChildTaxMask = createFormatter("######.##");
	MaskFormatter RentMortgageMask = createFormatter("######.##");
	MaskFormatter GasHydroMask = createFormatter("######.##");
	MaskFormatter PhoneTVMask = createFormatter("######.##");
	MaskFormatter ChildCareMask = createFormatter("######.##");
	MaskFormatter TransitGasMask = createFormatter("######.##");
	MaskFormatter LoansInsuranceMask = createFormatter("######.##");
	MaskFormatter ShoeMask = createFormatter ("##.##");
	
	
	
	
	//Total income integers to prevent null pointer errors
	double a = 00000.00;
	double b = 00000.00;
	double c = 00000.00;
	double d = 00000.00;
	double e = 00000.00;
	double f = 00000.00;
	
	
	double z = 00000.00;
	double y = 00000.00;
	double x = 00000.00;
	double w = 00000.00;
	double v = 00000.00;
	double u = 00000.00;
	
	
	Object[] possibilities = {"Newmarket", "Aurora", "Markham"+
			  "Queensville","Sharon","Stouffville"+
			  "Mount Albert","Schomberg","Richmond Hill"+
			  "Holland Landing","Bradford","Vaughan"+
			  "East Gwillimbury","Georgina/Keswick"};
	private final ButtonGroup btngrpGenderChild1 = new ButtonGroup();
	private final ButtonGroup btngrpGenderChild2 = new ButtonGroup();
	private final ButtonGroup btngrpGenderChild3 = new ButtonGroup();
	private final JSeparator sepChildChild1AndChild2 = new JSeparator();
	private final JSeparator sepChildChild2AndChild3 = new JSeparator();
	private final JSeparator sepChildChild1AndStart = new JSeparator();
	private final JButton btnContinueOntoFinancial = new JButton("Continue onto financial information");
	private final JComboBox cbChild1Month = new JComboBox();
	private final JComboBox cbChild1Day = new JComboBox();
	private final JComboBox cbChild1Year = new JComboBox();
	private final JComboBox cbChild2Month = new JComboBox();
	private final JComboBox cbChild2Day = new JComboBox();
	private final JComboBox cbChild2Year = new JComboBox();
	private final JComboBox cbChild3Month = new JComboBox();
	private final JComboBox cbChild3Day = new JComboBox();
	private final JComboBox cbChild3Year = new JComboBox();
	private final JComboBox cbChildPanel2Child1Month = new JComboBox();
	private final JComboBox cbChildPanel2Child1Day = new JComboBox();
	private final JComboBox cbChildPanel2Child1Year = new JComboBox();
	private final JComboBox cbChildPanel2Child2Month = new JComboBox();
	private final JComboBox cbChildPanel2Child2Day = new JComboBox();
	private final JComboBox cbChildPanel2Child2Year = new JComboBox();
	private final JComboBox cbChildPanel2Child3Month = new JComboBox();
	private final JComboBox cbChildPanel2Child3Day = new JComboBox();
	private final JComboBox cbChildPanel2Child3Year = new JComboBox();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CumminsSACAPframe frame = new CumminsSACAPframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// This goes after main but before frame definition
		public MaskFormatter createFormatter(String s) {
			MaskFormatter formatter = null;
			try {
				formatter = new MaskFormatter(s);
	        } 
			catch (java.text.ParseException exc) {
				System.err.println("formatter is bad: " + exc.getMessage());
				System.exit(-1);
		    }
	      return formatter;
	}//createFormatter

	
	
	
	/**
	 * Create the frame.
	 */
	public CumminsSACAPframe() {
		jbinit();	
	}
	private void jbinit(){
		setTitle("CumminsSACAP");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 843, 703);
		
		
		setJMenuBar(menuBar);
		
		
		menuBar.add(mnFile);
		mntmStartNewForm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewForm();
			}
		});
		
		
		mnFile.add(mntmStartNewForm);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		JSeparator sepNewFormAndExit = new JSeparator();
		mnFile.add(sepNewFormAndExit);
		
		
		mnFile.add(mntmExit);
		
		
		menuBar.add(mnHelp);
		mntmApplicantPanelHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,
					    "First Name: Enter your first name only \n"
					    + "Last Name: Enter your last name only \n"
					    + "Address: Enter your full address  \n"
					    + "Postal Code: Enter your Postal/Zip Code \n"
					    + "Select Area: Select area of residence \n"
					    + "Phone Number: Enter your cell phone number \n"
					    + "Email: Enter your full Email address \n"
					    + "Number of Adults: Adults in your group \n"
					    + "Number of Children over 18: Enter how many children "
					    + "are over 18 \n"
					    + "Number of Children under 18: Enter how many children "
					    + "are 17 or under");
			}
		});
		
		
		
		mnHelp.add(mntmApplicantPanelHelp);
		
		JSeparator sepAppPanAndChildPan = new JSeparator();
		mnHelp.add(sepAppPanAndChildPan);
		mntmChildPanelHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,
						"Child first name: Enter your childs first name only \n"
						+ "Gender: Please select your childs gender \n"
						+ "Birthdate: Enter your childs date of birth \n"
						+ "month/day/year"
						+ "Age: Enter your childs current age \n"
						+ "Clothing Size: Select size that is best for your child \n"
						+ "Coat Size: Select your childs current coat size  \n"
						+ "Shoe Size: Enter your childs shoe size \n"
						+ "Gaming Systems: Select the gaming systems that your group owns"
						+ "Interests: Select topics that your child is interested in");
			}
		});
		
		
		mnHelp.add(mntmChildPanelHelp);
		
		JSeparator sepChildPanAndFinPan = new JSeparator();
		mnHelp.add(sepChildPanAndFinPan);
		mntmFinancialPanelHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, 
						"Employment(Total): Total salary earnings \n"
						+ "Child/Spousal Support: \n"
						+ "Ontario Works: If you recieve financial assistance"
						+ "Specify how much  \n"
						+ "Disability: If you recieve disabilty specify how much\n"
						+ "Pension Income: If you are recieve annual financial "
						+ "assistance specify how much\n"
						+ "Child Tax Credits: List how much you spend on your dependants \n"
						+ "Rent/Mortgage: Specify whether or not you pay rent or have a "
						+ "mortgage, specify that amount\n"
						+ "Gas/Hydro: Enter how much you spend on gas and water \n"
						+ "Phone/TV: Enter how much you spend on phone and cabel "
						+ "Child care: Enter how much you spend on your dependants \n"
						+ "Transit/Gas: Specify whether or not you use local transportation \n"
						+ "or if you own a car, enter the amount you spend on either \n"
						+ "Loans/Insurance: Enter how much you owe in loans if you have any");
			}
		});
		
		
		mnHelp.add(mntmFinancialPanelHelp);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		tabbedPane.setBounds(10, 38, 807, 563);
		contentPane.add(tabbedPane);
		ApplicantPanel.setToolTipText("Enter your last name here only");
		
		
		tabbedPane.addTab("Applicant information", null, ApplicantPanel, null);
		ApplicantPanel.setLayout(null);
		
		
		lblFirstName.setBounds(17, 22, 72, 34);
		ApplicantPanel.add(lblFirstName);
		
		tfFirstName = new JTextField();
		tfFirstName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if(!tfFirstName.getText().matches("[a-zA-Z]*")){
					JOptionPane.showMessageDialog(null, 
						"Invalid input, only enter letters "
						+ "into the first name text field\n");
					tfFirstName.requestFocus();	
			}
			}});
		tfFirstName.setToolTipText("Enter your first name only here");
		tfFirstName.setBounds(116, 26, 174, 27);
		ApplicantPanel.add(tfFirstName);
		tfFirstName.setColumns(10);
		
		
		lblLastName.setBounds(17, 80, 72, 34);
		ApplicantPanel.add(lblLastName);
		
		tfLastName = new JTextField();
		tfLastName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if(!tfLastName.getText().matches("[a-zA-Z]*")){
					JOptionPane.showMessageDialog(null, 
						"Invalid input, only enter letters "
						+ "into the first name text field\n");
					tfLastName.requestFocus();	
			}
			}});
		tfLastName.setColumns(10);
		tfLastName.setBounds(116, 84, 174, 27);
		ApplicantPanel.add(tfLastName);
		
		
		lblAddress.setBounds(17, 136, 72, 34);
		ApplicantPanel.add(lblAddress);
		
		tfAddress = new JTextField();
		tfAddress.setToolTipText("Enter full address");
		tfAddress.setColumns(10);
		tfAddress.setBounds(116, 140, 174, 27);
		ApplicantPanel.add(tfAddress);
		
		
		lblPostalCode.setBounds(17, 198, 72, 34);
		ApplicantPanel.add(lblPostalCode);
				
		
				lblPhoneNumber.setBounds(17, 326, 89, 34);
				ApplicantPanel.add(lblPhoneNumber);
				
				
				lblEmail.setBounds(378, 26, 72, 27);
				ApplicantPanel.add(lblEmail);
				
				tfEmail = new JTextField();
				tfEmail.setToolTipText("Enter your email address here");
				tfEmail.setColumns(10);
				tfEmail.setBounds(531, 26, 171, 27);
				ApplicantPanel.add(tfEmail);
				
				
				lblAdults.setBounds(376, 77, 123, 41);
				ApplicantPanel.add(lblAdults);
				
				PostalCodeMask.setPlaceholderCharacter('0');
				PostalCodeMask.install(ftfPostalCode);
				ftfPostalCode.addFocusListener(new FocusAdapter() {
					@Override
					public void focusLost(FocusEvent e) {
						if(!ftfPostalCode.getText().matches("[1-9]*")){
							JOptionPane.showMessageDialog(null, 
								"Invalid input, only enter integers "
								+ "into the postal code text field\n");
							ftfPostalCode.requestFocus();	
					}
					}
				});
				ftfPostalCode.setToolTipText("Enter Postal/Zip code");
				ftfPostalCode.setBounds(116, 202, 174, 27);
				ApplicantPanel.add(ftfPostalCode);
				
				PhoneMask.setPlaceholderCharacter('0');
				PhoneMask.install(ftfPhone);
				ftfPhone.setToolTipText("Enter your cell phone number");
				ftfPhone.setBounds(116, 330, 174, 27);
				ApplicantPanel.add(ftfPhone);
				
				AdultsMask.setPlaceholderCharacter('0');
				AdultsMask.install(ftfAdults);
				ftfAdults.setToolTipText("<HTML>\r\nEnter number of adults <br>\r\nthat are in your group\r\n</HTML>");
				ftfAdults.setBounds(531, 84, 171, 27);
				ApplicantPanel.add(ftfAdults);
				
			
				lblChildrenOver.setBounds(378, 145, 136, 46);
				ApplicantPanel.add(lblChildrenOver);
				

				ChildrenOverMask.setPlaceholderCharacter('0');
				ChildrenOverMask.install(ftfChildrenOver);
				ftfChildrenOver.setToolTipText("<HTML>\r\nEnter number of children<br>\r\nover the age of 18 <br>\r\nthat are in your group\r\n</HTML>");
				ftfChildrenOver.setBounds(531, 154, 171, 28);
				ApplicantPanel.add(ftfChildrenOver);
				
				
				lblChildrenUnder.setBounds(378, 254, 143, 42);
				ApplicantPanel.add(lblChildrenUnder);
				
				ChildrenUnderMask.setPlaceholderCharacter('0');
				ChildrenUnderMask.install(ftfChildrenUnder);
				ftfChildrenUnder.setToolTipText("<HTML>\r\nEnter number of children<br>\r\nunder the age of 18 <br>\r\nthat are in your group\r\n</HTML>");
				ftfChildrenUnder.setBounds(531, 262, 165, 27);
				ApplicantPanel.add(ftfChildrenUnder);
				
				JComboBox cbSelectArea = new JComboBox();
				cbSelectArea.setToolTipText("Select the area you live in");
				cbSelectArea.setModel(new DefaultComboBoxModel(new String[] {"--Select Area--", "Newmarket", "Aurora", "Markham", "Queensville", "Sharon", "Slouthville", "Mount Albert", "Schomberg", "Richmond Hill", "Holland Landing", "Bradford", "Vaughan", "East Gwillimbury", "Georgina/Keswick"}));
				cbSelectArea.setBounds(114, 275, 176, 33);
				ApplicantPanel.add(cbSelectArea);
				ApplicantPanel.setFocusCycleRoot(true);
				btnContinueOntoFinancial.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						if (tfFirstName.getText().equals("") || tfLastName.getText().equals("") ||
								tfAddress.getText().equals("") || ftfPostalCode.getText().equals("00000") ||
								ftfPhone.getText().equals("(000)-000-0000") ||
								cbSelectArea.getSelectedItem().equals("--Select Area--") ||
								tfEmail.getText().equals(null) || ftfAdults.getText().equals("00")){
								tabbedPane.setEnabledAt(1, false);{
								JOptionPane.showMessageDialog(null,"You appear to be missing \n"
										+ "some key information, fill that \n"
										+ "out before you advance to the next panel");
								}
						}
						else {
							tabbedPane.setEnabledAt(1, true);
							ftfEmployment.requestFocus();
						}
						if (tfFirstName.getText().isEmpty()){
							tfFirstName.requestFocus();
							lblFirstName.setForeground(Color.RED);
						}else {
							lblFirstName.setForeground(Color.BLACK);
						}
						
						if (tfLastName.getText().isEmpty()){
							tfLastName.requestFocus();
							lblLastName.setForeground(Color.RED);
						} else {
							lblLastName.setForeground(Color.BLACK);
						}
						if (tfAddress.getText().isEmpty()){
							tfAddress.requestFocus();
							lblAddress.setForeground(Color.RED);
						} else{
							lblAddress.setForeground(Color.BLACK);
						}
						if (ftfPostalCode.getText().equals("00000")){
							ftfPostalCode.requestFocus();
							lblPostalCode.setForeground(Color.RED);
						} else {
							lblPostalCode.setForeground(Color.BLACK);
						}
						if (ftfPhone.getText().equals("(000)-000-0000")){
							ftfPhone.requestFocus();
							lblPhoneNumber.setForeground(Color.RED);
						} else {
							lblPhoneNumber.setForeground(Color.BLACK);
						}
						if (cbSelectArea.getSelectedItem().equals("--Select Area--")){
							cbSelectArea.requestFocus();
							cbSelectArea.setForeground(Color.RED);
						} else {
							cbSelectArea.setForeground(Color.BLACK);
						}
						if (tfEmail.getText().isEmpty()){
							tfEmail.requestFocus();
							lblEmail.setForeground(Color.RED);
						} else{
							lblEmail.setForeground(Color.BLACK);
						}
						
						if (ftfAdults.getText().equals("00")){
							ftfAdults.requestFocus();
							lblAdults.setForeground(Color.RED);
						} else {
							lblAdults.setForeground(Color.BLACK);
						}
					
					}
				});
				btnContinueOntoFinancial.setBounds(383, 364, 319, 41);
				
				ApplicantPanel.add(btnContinueOntoFinancial);
				ApplicantPanel.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{tfFirstName, tfLastName, tfAddress, ftfPostalCode, cbSelectArea, ftfPhone, tfEmail, ftfAdults, ftfChildrenOver, ftfChildrenUnder}));

				tabbedPane.addTab("Financal information", null, FinancePanel, null);
				tabbedPane.setEnabledAt(1, false);
				
				
				
				
		FinancePanel.setLayout(null);
		
		ftfEmployment.setToolTipText("<HTML>\r\nEnter annual income <br>\r\nthat comes from your job\r\n</HTML>");
		
		lblEmploymenttotal.setBounds(0, 14, 109, 34);
		FinancePanel.add(lblEmploymenttotal);
		ftfEmployment.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalIncomeMath();
				TotalNetIncomeMath();
				
			}
		});
		
		
	
		ftfEmployment.setBounds(129, 18, 149, 27);
		EmploymentMask.setPlaceholderCharacter('0');
		EmploymentMask.install(ftfEmployment);
		FinancePanel.add(ftfEmployment);
		ftfSupport.setToolTipText("<HTML>\r\nIf you recieve child support <br>\r\nor alamony enter that amount here\r\n</HTML>");
		
		
		lblSupport.setBounds(0, 86, 149, 34);
		FinancePanel.add(lblSupport);
		
		
		lblOntario.setBounds(0, 144, 109, 34);
		FinancePanel.add(lblOntario);
		ftfSupport.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalIncomeMath();
				TotalNetIncomeMath();
			}
		});
		
		
		ftfSupport.setBounds(129, 83, 149, 31);
		SupportMask.setPlaceholderCharacter('0');
		SupportMask.install(ftfSupport);
		FinancePanel.add(ftfSupport);
		ftfOntario.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalIncomeMath();
				TotalNetIncomeMath();
			}
		});
		
		
		ftfOntario.setBounds(129, 151, 149, 31);
		OntarioMask.setPlaceholderCharacter('0');
		OntarioMask.install(ftfOntario);
		FinancePanel.add(ftfOntario);
		ftfDisability.setToolTipText("<HTML>\r\nIf you currently recieve <br>\r\ndisability checks enter that <br>\r\namount here\r\n</HTML>");
		
		
		lblDisability.setBounds(0, 206, 109, 34);
		FinancePanel.add(lblDisability);
		ftfDisability.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalIncomeMath();
				TotalNetIncomeMath();
			}
		});
		
		
		ftfDisability.setBounds(129, 213, 149, 27);
		DisabilityMask.setPlaceholderCharacter('0');
		DisabilityMask.install(ftfDisability);
		FinancePanel.add(ftfDisability);
		
		
		lblPensionIncome.setBounds(0, 262, 109, 34);
		FinancePanel.add(lblPensionIncome);
		ftfPensionIncome.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalIncomeMath();
				TotalNetIncomeMath();
			}
		});
		
		
		ftfPensionIncome.setBounds(129, 269, 150, 27);
		PensionMask.setPlaceholderCharacter('0');
		PensionMask.install(ftfPensionIncome);
		FinancePanel.add(ftfPensionIncome);
		
		
		lblChildTaxCredits.setBounds(0, 344, 109, 27);
		FinancePanel.add(lblChildTaxCredits);
		ftfChildTaxCredits.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalIncomeMath();
				TotalNetIncomeMath();
			}
		});
		
		
		ftfChildTaxCredits.setBounds(129, 340, 149, 34);
		ChildTaxMask.setPlaceholderCharacter('0');
		ChildTaxMask.install(ftfChildTaxCredits);
		FinancePanel.add(ftfChildTaxCredits);
		
		lblIncome.setBounds(129, 411, 190, 27);
		FinancePanel.add(lblIncome);
		
		
		btngrpRentMort.add(rdbtnRent);
		rdbtnRent.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
			}
		});
		rdbtnRent.setBounds(354, 10, 109, 23);
		FinancePanel.add(rdbtnRent);
		
		
		btngrpRentMort.add(rdbtnMortgage);
		rdbtnMortgage.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
			}
		});
		rdbtnMortgage.setBounds(354, 36, 109, 23);
		FinancePanel.add(rdbtnMortgage);
		ftfRentMortgage.setToolTipText("<HTML>\r\nAfter specifying if you <br>\r\nrent a home or pay a mortgage <br>\r\nplease enter said value\r\n</HTML>");
		ftfRentMortgage.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalExpensesMath();
				TotalNetIncomeMath();
			}
		});
		
		ftfRentMortgage.setForeground(Color.RED);
		
		ftfRentMortgage.setBounds(466, 18, 170, 27);
		RentMortgageMask.setPlaceholderCharacter('0');
		RentMortgageMask.install(ftfRentMortgage);
		FinancePanel.add(ftfRentMortgage);
		ftfGasHydro.setToolTipText("<HTML>\r\nEnter amount spent on <br>\r\ngas and water\r\n</HTML>\r\n");
		
		ftfGasHydro.setForeground(Color.RED);
		lblGasHydro.setBounds(354, 81, 109, 45);
		FinancePanel.add(lblGasHydro);
		ftfGasHydro.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalExpensesMath();
				TotalNetIncomeMath();
			}
		});
		
		
		ftfGasHydro.setBounds(466, 90, 170, 27);
		GasHydroMask.setPlaceholderCharacter('0');
		GasHydroMask.install(ftfGasHydro);
		FinancePanel.add(ftfGasHydro);
		ftfPhoneTv.setToolTipText("<HTML>\r\nEnter average payment on <br>\r\nphone and cable \r\n</HTML>");
		
		ftfPhoneTv.setForeground(Color.RED);
		lblPhoneTv.setBounds(354, 155, 89, 27);
		FinancePanel.add(lblPhoneTv);
		ftfPhoneTv.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalExpensesMath();
				TotalNetIncomeMath();
			}
		});
		
		
		ftfPhoneTv.setBounds(466, 152, 170, 30);
		PhoneTVMask.setPlaceholderCharacter('0');
		PhoneTVMask.install(ftfPhoneTv);
		FinancePanel.add(ftfPhoneTv);
		ftfChildCare.setToolTipText("<HTML>\r\nEnter amount spent to take <br>\r\ncare of dependents <br>\r\n</HTML>");
		
		ftfChildCare.setForeground(Color.RED);
		lblChildCare.setBounds(354, 206, 89, 34);
		FinancePanel.add(lblChildCare);
		ftfChildCare.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalExpensesMath();
				TotalNetIncomeMath();
			}
		});
		
		
		ftfChildCare.setBounds(466, 210, 170, 27);
		ChildCareMask.setPlaceholderCharacter('0');
		ChildCareMask.install(ftfChildCare);
		FinancePanel.add(ftfChildCare);
		
		
		btngrpTransitGas.add(rdbtnTransit);
		rdbtnTransit.setBounds(354, 268, 109, 23);
		FinancePanel.add(rdbtnTransit);
		
		
		btngrpTransitGas.add(rdbtnGas);
		rdbtnGas.setBounds(354, 294, 109, 23);
		FinancePanel.add(rdbtnGas);
		ftfTransitGas.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalExpensesMath();
				TotalNetIncomeMath();
			}
		});
		
		ftfTransitGas.setForeground(Color.RED);
		ftfTransitGas.setBounds(466, 284, 170, 27);
		TransitGasMask.setPlaceholderCharacter('0');
		TransitGasMask.install(ftfTransitGas);
		FinancePanel.add(ftfTransitGas);
		
		ftfLoansInsurance.setForeground(Color.RED);
		lblLoansInsurance.setBounds(354, 344, 131, 27);
		FinancePanel.add(lblLoansInsurance);
		ftfLoansInsurance.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				TotalExpensesMath();
				TotalNetIncomeMath();
				TransitGasMask.install(ftfTransitGas);
			}
		});
		
		
		ftfLoansInsurance.setBounds(466, 342, 170, 30);
		LoansInsuranceMask.setPlaceholderCharacter('0');
		LoansInsuranceMask.install(ftfLoansInsurance);
		FinancePanel.add(ftfLoansInsurance);
		
		
		lblTotalExpenses.setBounds(466, 413, 205, 23);
		FinancePanel.add(lblTotalExpenses);
		lblTotalExpenses.setForeground(Color.RED);
		
		
		sepFinTopTopLeftHor.setBounds(0, 59, 308, 15);
		FinancePanel.add(sepFinTopTopLeftHor);
		
		
		sepFinTopLeft.setBounds(0, 125, 308, 15);
		FinancePanel.add(sepFinTopLeft);
		
		
		sepFinTopLeftMid.setBounds(0, 189, 308, 15);
		FinancePanel.add(sepFinTopLeftMid);
		
		
		sepFinBotLeftMid.setBounds(0, 251, 308, 15);
		FinancePanel.add(sepFinBotLeftMid);
		
		
		sepFinBotLeft.setBounds(0, 325, 308, 15);
		FinancePanel.add(sepFinBotLeft);
		
		
		sepFinBotRightHor.setBounds(308, 325, 510, 23);
		FinancePanel.add(sepFinBotRightHor);
		
		
		sepFinBotRightMid.setBounds(307, 251, 511, 15);
		FinancePanel.add(sepFinBotRightMid);
		
		
		sepFinTopRightMid.setBounds(308, 189, 510, 15);
		FinancePanel.add(sepFinTopRightMid);
		
		
		sepFinTopRight.setBounds(308, 126, 510, 15);
		FinancePanel.add(sepFinTopRight);
		
		
		sepFinTopTopRightHor.setBounds(308, 59, 510, 15);
		FinancePanel.add(sepFinTopTopRightHor);
		
	
		sepFinMiddleVert.setOrientation(SwingConstants.VERTICAL);
		sepFinMiddleVert.setBounds(308, 0, 11, 401);
		FinancePanel.add(sepFinMiddleVert);
		
		
		sepFinBotBotRight.setBounds(0, 399, 308, 2);
		FinancePanel.add(sepFinBotBotRight);
		
		
		sepFinBotRight.setBounds(308, 399, 510, 2);
		FinancePanel.add(sepFinBotRight);
		
		
		lblNetIncome.setBounds(681, 414, 149, 21);
		FinancePanel.add(lblNetIncome);
		FinancePanel.setFocusCycleRoot(true);
		FinancePanel.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{ftfEmployment, ftfSupport, ftfOntario, ftfDisability, ftfPensionIncome, ftfChildTaxCredits, rdbtnRent, rdbtnMortgage, ftfRentMortgage, ftfGasHydro, ftfPhoneTv, ftfChildCare, rdbtnTransit, rdbtnGas, ftfTransitGas, ftfLoansInsurance}));
		tabbedPane.addTab("Children Panel", null, ChildPanel, null);
		
		
		
		ChildPanel.setLayout(null);
		
		
		lblChildFirstName.setBounds(0, 25, 113, 25);
		ChildPanel.add(lblChildFirstName);
		
		
		lblGender.setBounds(0, 72, 78, 14);
		ChildPanel.add(lblGender);
		
		
		lblBirthdate.setBounds(0, 120, 132, 14);
		ChildPanel.add(lblBirthdate);
		
		
		lblAge.setBounds(0, 168, 46, 14);
		ChildPanel.add(lblAge);
		
		
		lblClothingSize.setBounds(0, 214, 88, 14);
		ChildPanel.add(lblClothingSize);
		
		
		lblShoeSize.setBounds(0, 264, 78, 14);
		ChildPanel.add(lblShoeSize);
		
		
		lblCoatSize.setBounds(0, 309, 67, 14);
		ChildPanel.add(lblCoatSize);
		
		
		lblWhatGameSystems.setBounds(0, 357, 195, 14);
		ChildPanel.add(lblWhatGameSystems);
		
		
		lblWhatAreYour.setBounds(0, 460, 178, 14);
		ChildPanel.add(lblWhatAreYour);
		ftfChild1Name.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if(!ftfChild1Name.getText().matches("[a-zA-Z]*")){
					JOptionPane.showMessageDialog(null, 
						"Invalid input, only enter letters "
						+ "into the child name text field\n");
					ftfChild1Name.requestFocus();	
			}
			}
		});
		ftfChild1Name.setToolTipText("Enter name of your child");
		
		
		ftfChild1Name.setBounds(195, 26, 155, 23);
		ChildPanel.add(ftfChild1Name);
		ftfChild2Name.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if(!ftfChild2Name.getText().matches("[a-zA-Z]*")){
					JOptionPane.showMessageDialog(null, 
						"Invalid input, only enter letters "
						+ "into the child name text field\n");
					ftfChild2Name.requestFocus();
			}
		}});
		ftfChild2Name.setToolTipText("Enter name of your child");
		
		
		ftfChild2Name.setBounds(413, 26, 155, 23);
		ChildPanel.add(ftfChild2Name);
		ftfChild3Name.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if(!ftfChild3Name.getText().matches("[a-zA-Z]*")){
					JOptionPane.showMessageDialog(null, 
						"Invalid input, only enter letters "
						+ "into the child name text field\n");
					ftfChild3Name.requestFocus();
			}
		}
			
			}
		);
		ftfChild3Name.setToolTipText("Enter name of your child");
		
		
		ftfChild3Name.setBounds(626, 26, 155, 23);
		ChildPanel.add(ftfChild3Name);
		
		
		btngrpGenderChild1.add(rdbtnChild1Male);
		rdbtnChild1Male.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is male\r\n</HTML>");
		rdbtnChild1Male.setBounds(195, 68, 52, 23);
		ChildPanel.add(rdbtnChild1Male);
		
		
		btngrpGenderChild1.add(rdbtnChild1Female);
		rdbtnChild1Female.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is female\r\n</HTML>");
		rdbtnChild1Female.setBounds(283, 68, 67, 23);
		ChildPanel.add(rdbtnChild1Female);
		
		
		btngrpGenderChild2.add(rdbtnChild2Male);
		rdbtnChild2Male.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is male\r\n</HTML>");
		rdbtnChild2Male.setBounds(413, 68, 60, 23);
		ChildPanel.add(rdbtnChild2Male);
		
		
		btngrpGenderChild2.add(rdbtnChild2Female);
		rdbtnChild2Female.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is female\r\n</HTML>");
		rdbtnChild2Female.setBounds(501, 68, 67, 23);
		ChildPanel.add(rdbtnChild2Female);
		
		
		btngrpGenderChild3.add(rdbtnChild3Male);
		rdbtnChild3Male.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is male\r\n</HTML>");
		rdbtnChild3Male.setBounds(626, 68, 52, 23);
		ChildPanel.add(rdbtnChild3Male);
		
		
		btngrpGenderChild3.add(rdbtnChild3Female);
		rdbtnChild3Female.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is female\r\n</HTML>");
		rdbtnChild3Female.setBounds(703, 68, 78, 23);
		ChildPanel.add(rdbtnChild3Female);
		
		
		ftfChild1Age.setToolTipText("Enter current age of child");
		
		
		ftfChild1Age.setBounds(195, 164, 155, 23);
		ChildPanel.add(ftfChild1Age);
		ftfChild2Age.setToolTipText("Enter current age of child");
		
		
		ftfChild2Age.setBounds(413, 164, 155, 23);
		ChildPanel.add(ftfChild2Age);
		ftfChild3Age.setToolTipText("Enter current age of child");
		
		
		ftfChild3Age.setBounds(626, 164, 155, 23);
		ChildPanel.add(ftfChild3Age);
		ftfChild1Shoe.setToolTipText("Enter child's shoe size");
		
		ShoeMask.setPlaceholder("0");
		ShoeMask.install(ftfChild1Shoe);
		ftfChild1Shoe.setBounds(195, 260, 155, 23);
		ChildPanel.add(ftfChild1Shoe);
		ftfChild2Shoe.setToolTipText("Enter child's shoe size");
		
		ShoeMask.setPlaceholder("0");
		ShoeMask.install(ftfChild2Shoe);
		ftfChild2Shoe.setBounds(413, 260, 155, 23);
		ChildPanel.add(ftfChild2Shoe);
		ftfChild3Shoe.setToolTipText("Enter child's shoe size");
		
		ShoeMask.setPlaceholder("0");
		ShoeMask.install(ftfChild3Shoe);
		ftfChild3Shoe.setBounds(626, 260, 155, 23);
		ChildPanel.add(ftfChild3Shoe);
		ftfChild1Coat.setToolTipText("Enter child's coat size");
		
		ShoeMask.setPlaceholder("0");
		ShoeMask.install(ftfChild1Coat);
		ftfChild1Coat.setBounds(195, 305, 155, 23);
		ChildPanel.add(ftfChild1Coat);
		ftfChild2Coat.setToolTipText("Enter child's coat size");
		
		ShoeMask.setPlaceholder("0");
		ShoeMask.install(ftfChild2Coat);
		ftfChild2Coat.setBounds(413, 305, 155, 23);
		ChildPanel.add(ftfChild2Coat);
		ftfChild3Coat.setToolTipText("Enter child's coat size");
		
		ShoeMask.setPlaceholder("0");
		ShoeMask.install(ftfChild3Shoe);
		ftfChild3Coat.setBounds(626, 305, 155, 23);
		ChildPanel.add(ftfChild3Coat);
		
		JScrollPane spChild1GameSystems = new JScrollPane();
		spChild1GameSystems.setBounds(195, 356, 155, 71);
		ChildPanel.add(spChild1GameSystems);
		
		JList listChild1GameSystems = new JList();
		listChild1GameSystems.setToolTipText("<HTML>\r\nSelect the game systems <br>\r\nthat you own\r\n</HTML>");
		spChild1GameSystems.setViewportView(listChild1GameSystems);
		listChild1GameSystems.setModel(new AbstractListModel() {
			String[] values = new String[] {"Xbox 360", "Xbox 1", "Computer", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		
		JScrollPane spChild2GameSystems = new JScrollPane();
		spChild2GameSystems.setBounds(413, 356, 155, 72);
		ChildPanel.add(spChild2GameSystems);
		
		JList listChild2GameSystems = new JList();
		listChild2GameSystems.setToolTipText("<HTML>\r\nSelect the game systems <br>\r\nthat you own\r\n</HTML>");
		spChild2GameSystems.setViewportView(listChild2GameSystems);
		listChild2GameSystems.setModel(new AbstractListModel() {
			String[] values = new String[] {"Xbox 360", "Xbox 1", "Computer", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		
		JScrollPane spChild3GameSystems = new JScrollPane();
		spChild3GameSystems.setBounds(626, 356, 155, 73);
		ChildPanel.add(spChild3GameSystems);
		
		JList listChild3GameSystems = new JList();
		listChild3GameSystems.setToolTipText("<HTML>\r\nSelect the game systems <br>\r\nthat you own\r\n</HTML>");
		spChild3GameSystems.setViewportView(listChild3GameSystems);
		listChild3GameSystems.setModel(new AbstractListModel() {
			String[] values = new String[] {"Xbox 360", "Xbox 1", "Computer", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		
		JScrollPane spChild1Interests = new JScrollPane();
		spChild1Interests.setBounds(195, 459, 155, 69);
		ChildPanel.add(spChild1Interests);
		
		JList listChild1Interests = new JList();
		listChild1Interests.setToolTipText("<HTML>\r\nSelect some of your<br>\r\nchilds interests\r\n</HTML>");
		spChild1Interests.setViewportView(listChild1Interests);
		listChild1Interests.setModel(new AbstractListModel() {
			String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trucks", "Music", "Lego/Duplo", "Construction", "Outdoors", "Dolls", "Sports"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		
		JScrollPane spChild2Interests = new JScrollPane();
		spChild2Interests.setBounds(413, 459, 155, 69);
		ChildPanel.add(spChild2Interests);
		
		JList listChild2Interests = new JList();
		listChild2Interests.setToolTipText("<HTML>\r\nSelect some of your<br>\r\nchilds interests\r\n</HTML>");
		spChild2Interests.setViewportView(listChild2Interests);
		listChild2Interests.setModel(new AbstractListModel() {
			String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trucks", "Music", "Lego/Duplo", "Construction", "Outdoors", "Dolls", "Sports"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		
		JScrollPane spChild3Interests = new JScrollPane();
		spChild3Interests.setBounds(626, 459, 155, 69);
		ChildPanel.add(spChild3Interests);
		
		JList listChild3Interests = new JList();
		listChild3Interests.setToolTipText("<HTML>\r\nSelect some of your<br>\r\nchilds interests\r\n</HTML>");
		spChild3Interests.setViewportView(listChild3Interests);
		listChild3Interests.setModel(new AbstractListModel() {
			String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trucks", "Music", "Lego/Duplo", "Construction", "Outdoors", "Dolls", "Sports"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		sepChildChild1AndChild2.setOrientation(SwingConstants.VERTICAL);
		sepChildChild1AndChild2.setBounds(371, 0, 24, 539);
		
		ChildPanel.add(sepChildChild1AndChild2);
		sepChildChild2AndChild3.setOrientation(SwingConstants.VERTICAL);
		sepChildChild2AndChild3.setBounds(592, 0, 24, 539);
		
		ChildPanel.add(sepChildChild2AndChild3);
		sepChildChild1AndStart.setOrientation(SwingConstants.VERTICAL);
		sepChildChild1AndStart.setBounds(188, 0, 24, 539);
		
		ChildPanel.add(sepChildChild1AndStart);
		
		JComboBox cbChild1ClothingSize = new JComboBox();
		cbChild1ClothingSize.setModel(new DefaultComboBoxModel(new String[] {"--Select Size--", "Extra Small", "Small", "Medium", "Large", "Extra Large", "2x Extra Large"}));
		cbChild1ClothingSize.setBounds(195, 209, 155, 27);
		ChildPanel.add(cbChild1ClothingSize);
		
		JComboBox cbChild2ClothingSize = new JComboBox();
		cbChild2ClothingSize.setModel(new DefaultComboBoxModel(new String[] {"--Select Size--", "Extra Small", "Small", "Medium", "Large", "Extra Large", "2x Extra Large"}));
		cbChild2ClothingSize.setBounds(413, 209, 155, 27);
		ChildPanel.add(cbChild2ClothingSize);
		
		JComboBox cdChild3ClothingSize = new JComboBox();
		cdChild3ClothingSize.setModel(new DefaultComboBoxModel(new String[] {"--Select Size--", "Extra Small", "Small", "Medium", "Large", "Extra Large", "2x Extra Large"}));
		cdChild3ClothingSize.setBounds(626, 209, 155, 27);
		ChildPanel.add(cdChild3ClothingSize);
		
		JButton btnNewChild = new JButton("Add more Children");
		btnNewChild.setEnabled(true);
		btnNewChild.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewChild();
				btnNewChild.setEnabled(false);
			}
		});
		btnNewChild.setToolTipText("<HTML>\r\nIn case you need to <br>\r\nput down more than 3 <br>\r\nchildren, click to bring up <br>\r\nan additional form\r\n</HTML>");
		btnNewChild.setBounds(0, 505, 160, 23);
		ChildPanel.add(btnNewChild);
		
		
	
		cbChild1Month.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		cbChild1Month.setBounds(195, 117, 46, 25);
		ChildPanel.add(cbChild1Month);
		cbChild1Day.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		cbChild1Day.setBounds(244, 117, 46, 25);
		
		ChildPanel.add(cbChild1Day);
		cbChild1Year.setModel(new DefaultComboBoxModel(new String[] {"2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990"}));
		cbChild1Year.setBounds(293, 117, 57, 25);
		
		ChildPanel.add(cbChild1Year);
		cbChild2Month.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		cbChild2Month.setBounds(405, 117, 46, 25);
		
		ChildPanel.add(cbChild2Month);
		cbChild2Day.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		cbChild2Day.setBounds(458, 117, 46, 25);
		
		ChildPanel.add(cbChild2Day);
		cbChild2Year.setModel(new DefaultComboBoxModel(new String[] {"2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990"}));
		cbChild2Year.setBounds(514, 117, 60, 25);
		
		ChildPanel.add(cbChild2Year);
		cbChild3Month.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		cbChild3Month.setBounds(626, 117, 46, 25);
		
		ChildPanel.add(cbChild3Month);
		cbChild3Day.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		cbChild3Day.setBounds(682, 117, 46, 25);
		
		ChildPanel.add(cbChild3Day);
		cbChild3Year.setModel(new DefaultComboBoxModel(new String[] {"2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990"}));
		cbChild3Year.setBounds(735, 117, 57, 25);
		
		ChildPanel.add(cbChild3Year);
		ChildPanel.setFocusCycleRoot(true);
		ChildPanel.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{ftfChild1Name, rdbtnChild1Male, rdbtnChild1Female, ftfChild1Age, cbChild1ClothingSize, ftfChild1Shoe, ftfChild1Coat, listChild1GameSystems, listChild1Interests, ftfChild2Name, rdbtnChild2Male, rdbtnChild2Female, ftfChild2Age, cbChild2ClothingSize, ftfChild2Shoe, ftfChild2Coat, listChild2GameSystems, listChild2Interests, ftfChild3Name, rdbtnChild3Male, rdbtnChild3Female, ftfChild3Age, cdChild3ClothingSize, ftfChild3Shoe, ftfChild3Coat, listChild3GameSystems, listChild3Interests, btnNewChild}));
		
		JLabel lblTheSalvationArmy = new JLabel("The Salvation Army 2016 Christmas Assistance Program");
		lblTheSalvationArmy.setForeground(Color.BLACK);
		lblTheSalvationArmy.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblTheSalvationArmy.setBounds(10, 11, 845, 24);
		contentPane.add(lblTheSalvationArmy);
	}
	protected void TotalIncomeMath(){
		double a = Double.parseDouble(ftfEmployment.getText());
		double b = Double.parseDouble(ftfSupport.getText());
		double c = Double.parseDouble(ftfOntario.getText());
		double d = Double.parseDouble(ftfDisability.getText());
		double e = Double.parseDouble(ftfPensionIncome.getText());
		double f = Double.parseDouble(ftfChildTaxCredits.getText());
		double IncomeSum = a + b + c + d + e + f;
		lblIncome.setText("Total Income: " + IncomeSum);
	}
	
	//Calculates Total Expenses
	protected void TotalExpensesMath(){
		double z = Double.parseDouble(ftfRentMortgage.getText());
		double y = Double.parseDouble(ftfGasHydro.getText());
		double x = Double.parseDouble(ftfPhoneTv.getText());
		double w = Double.parseDouble(ftfChildCare.getText());
		double v = Double.parseDouble(ftfTransitGas.getText());
		double u = Double.parseDouble(ftfLoansInsurance.getText());
		double ExpensesSum = z + y + w + x + v + u;
		lblTotalExpenses.setText("Total Expenses: " + ExpensesSum);
	}
	
	//Calculates total net income using all the formatted text field inputs
	protected void TotalNetIncomeMath(){
		double a = Double.parseDouble(ftfEmployment.getText());
		double b = Double.parseDouble(ftfSupport.getText());
		double c = Double.parseDouble(ftfOntario.getText());
		double d = Double.parseDouble(ftfDisability.getText());
		double e = Double.parseDouble(ftfPensionIncome.getText());
		double f = Double.parseDouble(ftfChildTaxCredits.getText());
		double z = Double.parseDouble(ftfRentMortgage.getText());
		double y = Double.parseDouble(ftfGasHydro.getText());
		double x = Double.parseDouble(ftfPhoneTv.getText());
		double w = Double.parseDouble(ftfChildCare.getText());
		double v = Double.parseDouble(ftfTransitGas.getText());
		double u = Double.parseDouble(ftfLoansInsurance.getText());
		double NetIncome = (a+b+c+d+e+f)-(z+y+x+w+v+u);
		lblNetIncome.setText("Net Income: " + NetIncome);
		if (NetIncome >=0)
			lblNetIncome.setForeground(Color.BLACK);
		else
			lblNetIncome.setForeground(Color.RED);
			
	}
	//Clears all input fields
	protected void NewForm(){
		this.dispose();
		CumminsSACAPframe frame = new CumminsSACAPframe();
		frame.setVisible(true);
	} 
	
	
	
	//Copy of ChildPanel is created to give the user more child slots
	protected void NewChild(){
		
		final JPanel ChildPanel2 = new JPanel();
		tabbedPane.addTab("Additional Children Panel", null, ChildPanel2, null);
		ChildPanel2.setLayout(null);
		JLabel lblChildPanel2FirstName = new JLabel("Child First Name: ");	
		JLabel lblChildPanel2Gender = new JLabel("Gender:");
		JLabel lblChildPanel2ClothingSize = new JLabel("Clothing Size: ");
		JLabel lblChildPanel2Birthdate = new JLabel("Birthdate (mm/dd/yy): ");
		
		JLabel lblChildPanel2ShoeSize = new JLabel("Shoe Size:");
		JLabel lblChildPanel2CoatSize = new JLabel("Coat Size:");
		JLabel lblChildPanel2WhatGameSystems = new JLabel("What game system do you have?");
		JLabel lblChildPanel2WhatAreYour = new JLabel("What are your childs interests?");
		JLabel lblChildPanel2Age = new JLabel("Age:");
		JTextField ftfChildPanel2Child1Name = new JTextField();
		JTextField ftfChildPanel2Child2Name = new JTextField();
		JTextField ftfChildPanel2Child3Name = new JTextField();

		
		JRadioButton rdbtnChildPanel2Child1Male = new JRadioButton("Male");
		JRadioButton rdbtnChildPanel2Child1Female = new JRadioButton("Female");
		JRadioButton rdbtnChildPanel2Child2Male = new JRadioButton("Male");
		JRadioButton rdbtnChildPanel2Chidl2Female = new JRadioButton("Female");
		JRadioButton rdbtnChildPanel2Child3Female = new JRadioButton("Female");
		JRadioButton rdbtnChildPanel2Child3Male = new JRadioButton("Male");
		
		
		final ButtonGroup btngrpChildPanel2GenderChild1 = new ButtonGroup();
		final ButtonGroup btngrpChildPanel2GenderChild2 = new ButtonGroup();
		final ButtonGroup btngrpChildPanel2GenderChild3 = new ButtonGroup();
		
		
		JFormattedTextField ftfChildPanel2Child1Birth = new JFormattedTextField(numFormat);
		JFormattedTextField ftfChildPanel2Child2Birth = new JFormattedTextField(numFormat);
		JFormattedTextField ftfChildPanel2Child3Birth = new JFormattedTextField(numFormat);
		
		
		JFormattedTextField ftfChildPanel2Child1Shoe = new JFormattedTextField(numFormat);
		JFormattedTextField ftfChildPanel2Child2Shoe = new JFormattedTextField(numFormat);
		JFormattedTextField ftfChildPanel2Child3Shoe = new JFormattedTextField(numFormat);
	
		JFormattedTextField ftfChildPanel2Child1Coat = new JFormattedTextField(numFormat);
		JFormattedTextField ftfChildPanel2Child2Coat = new JFormattedTextField(numFormat);
		JFormattedTextField ftfChildPanel2Child3Coat = new JFormattedTextField(numFormat);
		
		JFormattedTextField ftfChildPanel2Child1Age = new JFormattedTextField(numFormat);
		JFormattedTextField ftfChildPanel2Child2Age = new JFormattedTextField(numFormat);
		JFormattedTextField ftfChildPanel2Child3Age = new JFormattedTextField(numFormat);
		
		final JSeparator sepChildPanel2ChildChild1AndChild2 = new JSeparator();
		final JSeparator sepChildPanel2ChildChild2AndChild3 = new JSeparator();
		final JSeparator sepChildPanel2ChildChild1AndStart = new JSeparator();
		
		JComboBox ChildPanel2cbChild1ClothingSize = new JComboBox();
		ChildPanel2cbChild1ClothingSize.setModel(new DefaultComboBoxModel(new String[] {"--Select Size--","Extra Small", "Small", "Medium", "Large", "Extra Large", "2x Extra Large"}));
		ChildPanel2cbChild1ClothingSize.setBounds(195, 209, 155, 27);
		ChildPanel2.add(ChildPanel2cbChild1ClothingSize);
		
		JComboBox cbChildPanel2Child2ClothingSize = new JComboBox();
		cbChildPanel2Child2ClothingSize.setModel(new DefaultComboBoxModel(new String[] {"--Select Size--","Extra Small", "Small", "Medium", "Large", "Extra Large", "2x Extra Large"}));
		cbChildPanel2Child2ClothingSize.setBounds(413, 209, 155, 27);
		ChildPanel2.add(cbChildPanel2Child2ClothingSize);
		
		JComboBox cdChildPanel2Child3ClothingSize = new JComboBox();
		cdChildPanel2Child3ClothingSize.setModel(new DefaultComboBoxModel(new String[] {"--Select Size--","Extra Small", "Small", "Medium", "Large", "Extra Large", "2x Extra Large"}));
		cdChildPanel2Child3ClothingSize.setBounds(626, 209, 155, 27);
		ChildPanel2.add(cdChildPanel2Child3ClothingSize);
		
		lblChildPanel2FirstName.setBounds(0, 25, 113, 25);
			ChildPanel2.add(lblChildPanel2FirstName);
			
			
			lblChildPanel2Gender.setBounds(0, 72, 78, 14);
			ChildPanel2.add(lblChildPanel2Gender);
			
			
			lblChildPanel2Birthdate.setBounds(0, 120, 132, 14);
			ChildPanel2.add(lblChildPanel2Birthdate);
			
			
			lblChildPanel2Age.setBounds(0, 168, 46, 14);
			ChildPanel2.add(lblChildPanel2Age);
			
			
			lblChildPanel2ClothingSize.setBounds(0, 214, 88, 14);
			ChildPanel2.add(lblChildPanel2ClothingSize);
			
			
			lblChildPanel2ShoeSize.setBounds(0, 264, 78, 14);
			ChildPanel2.add(lblChildPanel2ShoeSize);
			
			
			lblChildPanel2CoatSize.setBounds(0, 309, 67, 14);
			ChildPanel2.add(lblChildPanel2CoatSize);
			
			
			lblChildPanel2WhatGameSystems.setBounds(0, 357, 195, 14);
			ChildPanel2.add(lblChildPanel2WhatGameSystems);
			
			
			lblChildPanel2WhatAreYour.setBounds(0, 460, 178, 14);
			ChildPanel2.add(lblChildPanel2WhatAreYour);
			
			cbChildPanel2Child1Month.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
			cbChildPanel2Child1Month.setBounds(195, 117, 46, 25);
			ChildPanel2.add(cbChildPanel2Child1Month);
			cbChildPanel2Child1Day.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
			cbChildPanel2Child1Day.setBounds(244, 117, 46, 25);
			
			ChildPanel2.add(cbChildPanel2Child1Day);
			cbChildPanel2Child1Year.setModel(new DefaultComboBoxModel(new String[] {"2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990"}));
			cbChildPanel2Child1Year.setBounds(293, 117, 57, 25);
			
			ChildPanel2.add(cbChildPanel2Child1Year);
			cbChildPanel2Child2Month.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
			cbChildPanel2Child2Month.setBounds(405, 117, 46, 25);
			
			ChildPanel2.add(cbChildPanel2Child2Month);
			cbChildPanel2Child2Day.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
			cbChildPanel2Child2Day.setBounds(458, 117, 46, 25);
			
			ChildPanel2.add(cbChildPanel2Child2Day);
			cbChildPanel2Child2Year.setModel(new DefaultComboBoxModel(new String[] {"2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990"}));
			cbChildPanel2Child2Year.setBounds(514, 117, 60, 25);
			
			ChildPanel2.add(cbChildPanel2Child2Year);
			cbChildPanel2Child3Month.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
			cbChildPanel2Child3Month.setBounds(626, 117, 46, 25);
			
			ChildPanel2.add(cbChildPanel2Child3Month);
			cbChildPanel2Child3Day.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
			cbChildPanel2Child3Day.setBounds(682, 117, 46, 25);
			
			ChildPanel2.add(cbChildPanel2Child3Day);
			cbChildPanel2Child3Year.setModel(new DefaultComboBoxModel(new String[] {"2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990"}));
			cbChildPanel2Child3Year.setBounds(735, 117, 57, 25);
			
			ChildPanel2.add(cbChildPanel2Child3Year);
			
			
			ftfChildPanel2Child1Name.setToolTipText("Enter name of your child");
			
			
			
			ftfChildPanel2Child1Name.setBounds(195, 26, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child1Name);
			ftfChildPanel2Child1Name.setToolTipText("Enter name of your child");
			
			
			ftfChildPanel2Child1Name.setBounds(413, 26, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child1Name);
			ftfChildPanel2Child1Name.setToolTipText("Enter name of your child");
			
			
			ftfChildPanel2Child1Name.setBounds(626, 26, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child1Name);
			
			
			btngrpChildPanel2GenderChild1.add(rdbtnChildPanel2Child1Male);
			rdbtnChildPanel2Child1Male.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is male\r\n</HTML>");
			rdbtnChildPanel2Child1Male.setBounds(195, 68, 52, 23);
			ChildPanel2.add(rdbtnChildPanel2Child1Male);
			
			
			btngrpChildPanel2GenderChild1.add(rdbtnChildPanel2Child1Female);
			rdbtnChildPanel2Child1Female.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is female\r\n</HTML>");
			rdbtnChildPanel2Child1Female.setBounds(283, 68, 67, 23);
			ChildPanel2.add(rdbtnChildPanel2Child1Female);
			
			ftfChildPanel2Child1Name.setToolTipText("Enter name of your child");
			
			
			ftfChildPanel2Child1Name.setBounds(195, 26, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child1Name);
			ftfChildPanel2Child2Name.setToolTipText("Enter name of your child");
			
			
			ftfChildPanel2Child2Name.setBounds(413, 26, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child2Name);
			ftfChildPanel2Child3Name.setToolTipText("Enter name of your child");
			
			
			ftfChildPanel2Child3Name.setBounds(626, 26, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child3Name);
			
			
			btngrpChildPanel2GenderChild2.add(rdbtnChildPanel2Child2Male);
			rdbtnChildPanel2Child2Male.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is male\r\n</HTML>");
			rdbtnChildPanel2Child2Male.setBounds(413, 68, 60, 23);
			ChildPanel2.add(rdbtnChildPanel2Child2Male);
			
			
			btngrpChildPanel2GenderChild2.add(rdbtnChildPanel2Chidl2Female);
			rdbtnChildPanel2Chidl2Female.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is female\r\n</HTML>");
			rdbtnChildPanel2Chidl2Female.setBounds(501, 68, 67, 23);
			ChildPanel2.add(rdbtnChildPanel2Chidl2Female);
			
			
			btngrpChildPanel2GenderChild3.add(rdbtnChildPanel2Child3Male);
			rdbtnChildPanel2Child3Male.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is male\r\n</HTML>");
			rdbtnChildPanel2Child3Male.setBounds(626, 68, 52, 23);
			ChildPanel2.add(rdbtnChildPanel2Child3Male);
			
			
			btngrpChildPanel2GenderChild3.add(rdbtnChildPanel2Child3Female);
			rdbtnChildPanel2Child3Female.setToolTipText("<HTML>\r\nSelect this if your <br>\r\nchild is female\r\n</HTML>");
			rdbtnChildPanel2Child3Female.setBounds(703, 68, 78, 23);
			ChildPanel2.add(rdbtnChildPanel2Child3Female);
			cbChildPanel2Child3Year.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			cbChildPanel2Child3Month.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			cbChildPanel2Child3Day.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			
			cbChildPanel2Child2Year.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			cbChildPanel2Child2Month.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			cbChildPanel2Child2Day.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			
			cbChildPanel2Child1Year.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			cbChildPanel2Child1Month.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			cbChildPanel2Child1Day.setToolTipText("<HTML>\r\nEnter birth date<br>\r\nMonth/Day/Year\r\n</HTML>");
			
			ftfChildPanel2Child1Age.setToolTipText("Enter current age of child");
			
			
			ftfChildPanel2Child1Age.setBounds(195, 164, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child1Age);
			ftfChildPanel2Child2Age.setToolTipText("Enter current age of child");
			
			
			ftfChildPanel2Child2Age.setBounds(413, 164, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child2Age);
			ftfChildPanel2Child3Age.setToolTipText("Enter current age of child");
			
			
			ftfChildPanel2Child3Age.setBounds(626, 164, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child3Age);
			ftfChildPanel2Child1Shoe.setToolTipText("Enter child's shoe size");
			
			
			ftfChildPanel2Child1Shoe.setBounds(195, 260, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child1Shoe);
			ftfChildPanel2Child2Shoe.setToolTipText("Enter child's shoe size");
			
			
			ftfChildPanel2Child2Shoe.setBounds(413, 260, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child2Shoe);
			ftfChildPanel2Child3Shoe.setToolTipText("Enter child's shoe size");
			
			
			ftfChildPanel2Child3Shoe.setBounds(626, 260, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child3Shoe);
			ftfChildPanel2Child1Coat.setToolTipText("Enter child's coat size");
			
			
			ftfChildPanel2Child1Coat.setBounds(195, 305, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child1Coat);
			ftfChildPanel2Child2Coat.setToolTipText("Enter child's coat size");
			
			
			
			ftfChildPanel2Child2Coat.setBounds(413, 305, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child2Coat);
			ftfChildPanel2Child3Coat.setToolTipText("Enter child's coat size");
			
			
			ftfChildPanel2Child3Coat.setBounds(626, 305, 155, 23);
			ChildPanel2.add(ftfChildPanel2Child3Coat);
			
			sepChildPanel2ChildChild1AndChild2.setOrientation(SwingConstants.VERTICAL);
			sepChildPanel2ChildChild1AndChild2.setBounds(371, 0, 24, 539);
			
			ChildPanel2.add(sepChildPanel2ChildChild1AndChild2);
			sepChildPanel2ChildChild2AndChild3.setOrientation(SwingConstants.VERTICAL);
			sepChildPanel2ChildChild2AndChild3.setBounds(592, 0, 24, 539);
			
			ChildPanel2.add(sepChildPanel2ChildChild2AndChild3);
			sepChildPanel2ChildChild1AndStart.setOrientation(SwingConstants.VERTICAL);
			sepChildPanel2ChildChild1AndStart.setBounds(188, 0, 24, 539);
			
			ChildPanel2.add(sepChildPanel2ChildChild1AndStart);
			
			JScrollPane spChildPanel2Child1GameSystems = new JScrollPane();
			spChildPanel2Child1GameSystems.setBounds(195, 356, 155, 71);
			ChildPanel2.add(spChildPanel2Child1GameSystems);
			
			JList listChildPanel2Child1GameSystems = new JList();
			listChildPanel2Child1GameSystems.setToolTipText("<HTML>\r\nSelect the game systems <br>\r\nthat you own\r\n</HTML>");
			spChildPanel2Child1GameSystems.setViewportView(listChildPanel2Child1GameSystems);
			listChildPanel2Child1GameSystems.setModel(new AbstractListModel() {
				String[] values = new String[] {"Xbox 360", "Xbox 1", "Computer", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS"};
				public int getSize() {
					return values.length;
				}
				public Object getElementAt(int index) {
					return values[index];
				}
			});
			
			JScrollPane spChildPanel2Child2GameSystems = new JScrollPane();
			spChildPanel2Child2GameSystems.setBounds(413, 356, 155, 72);
			ChildPanel2.add(spChildPanel2Child2GameSystems);
			
			JList listChildPanel2Child2GameSystems = new JList();
			listChildPanel2Child2GameSystems.setToolTipText("<HTML>\r\nSelect the game systems <br>\r\nthat you own\r\n</HTML>");
			spChildPanel2Child2GameSystems.setViewportView(listChildPanel2Child2GameSystems);
			listChildPanel2Child2GameSystems.setModel(new AbstractListModel() {
				String[] values = new String[] {"Xbox 360", "Xbox 1", "Computer", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS"};
				public int getSize() {
					return values.length;
				}
				public Object getElementAt(int index) {
					return values[index];
				}
			});
			
			JScrollPane spChildPanel2Child3GameSystems = new JScrollPane();
			spChildPanel2Child3GameSystems.setBounds(626, 356, 155, 73);
			ChildPanel2.add(spChildPanel2Child3GameSystems);
			
			JList listChildPanel2Child3GameSystems = new JList();
			listChildPanel2Child3GameSystems.setToolTipText("<HTML>\r\nSelect the game systems <br>\r\nthat you own\r\n</HTML>");
			spChildPanel2Child3GameSystems.setViewportView(listChildPanel2Child3GameSystems);
			listChildPanel2Child3GameSystems.setModel(new AbstractListModel() {
				String[] values = new String[] {"Xbox 360", "Xbox 1", "Computer", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS"};
				public int getSize() {
					return values.length;
				}
				public Object getElementAt(int index) {
					return values[index];
				}
			});
			
			JScrollPane spChildPanel2Child1Interests = new JScrollPane();
			spChildPanel2Child1Interests.setBounds(195, 459, 155, 69);
			ChildPanel2.add(spChildPanel2Child1Interests);
			
			JList listChildPanel2Child1Interests = new JList();
			listChildPanel2Child1Interests.setToolTipText("<HTML>\r\nSelect some of your<br>\r\nchilds interests\r\n</HTML>");
			spChildPanel2Child1Interests.setViewportView(listChildPanel2Child1Interests);
			listChildPanel2Child1Interests.setModel(new AbstractListModel() {
				String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trucks", "Music", "Lego/Duplo", "Construction", "Outdoors", "Dolls", "Sports"};
				public int getSize() {
					return values.length;
				}
				public Object getElementAt(int index) {
					return values[index];
				}
			});
			
			JScrollPane spChildPanel2Child2Interests = new JScrollPane();
			spChildPanel2Child2Interests.setBounds(413, 459, 155, 69);
			ChildPanel2.add(spChildPanel2Child2Interests);
			
			JList listChildPanel2Child2Interests = new JList();
			listChildPanel2Child2Interests.setToolTipText("<HTML>\r\nSelect some of your<br>\r\nchilds interests\r\n</HTML>");
			spChildPanel2Child2Interests.setViewportView(listChildPanel2Child2Interests);
			listChildPanel2Child2Interests.setModel(new AbstractListModel() {
				String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trucks", "Music", "Lego/Duplo", "Construction", "Outdoors", "Dolls", "Sports"};
				public int getSize() {
					return values.length;
				}
				public Object getElementAt(int index) {
					return values[index];
				}
			});
			
			JScrollPane spChildPanel2Child3Interests = new JScrollPane();
			spChildPanel2Child3Interests.setBounds(626, 459, 155, 69);
			ChildPanel2.add(spChildPanel2Child3Interests);
			
			JList listChildPanel2Child3Interests = new JList();
			listChildPanel2Child3Interests.setToolTipText("<HTML>\r\nSelect some of your<br>\r\nchilds interests\r\n</HTML>");
			spChildPanel2Child3Interests.setViewportView(listChildPanel2Child3Interests);
			listChildPanel2Child3Interests.setModel(new AbstractListModel() {
				String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trucks", "Music", "Lego/Duplo", "Construction", "Outdoors", "Dolls", "Sports"};
				public int getSize() {
					return values.length;
				}
				public Object getElementAt(int index) {
					return values[index];
				}
			});
			
	}
}
